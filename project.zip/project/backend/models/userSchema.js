const mongoose = require('mongoose')

const userSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true
        },
        email: {
            type: String,
            required: true,
            unique: true
        },
        password: {
            type: String,
            required: true
        },
        otp: {
            type: String,
            required: true
        },
        role: {
            type: Number,
            default: 0
        },
        userInterests: [ {
            type: mongoose.ObjectId,
            ref: 'categories'
        }
        ],
        enrolledCourses: [
            {
            course: { 
            type: mongoose.ObjectId,
            ref: 'courses'
            },
            quiz1: Number,
            quiz2: Number,
            transcript: Number,
            status: {
                type: Boolean,
                default: false            
            },
            certificate: {
                type: Boolean,
                default: false
            }
            }

        ],
        skills: [{
            skill: {
                type: mongoose.ObjectId,
                ref: 'skills'
            },
            score: {
                type: Number,
                default: 0
            },
            level: {
                type: String,
                default: 'Beginner'
            }
        }
        ]
        
    },
    {
        timestamps: true
    }
)

const userModel = mongoose.model("users", userSchema)

module.exports = { userModel }

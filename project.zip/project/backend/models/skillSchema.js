const mongoose = require('mongoose')

const skillSchema = new mongoose.Schema({

  name: {
    type: String,
    required: true,
    unique: true
  },
  slug: {
    type: String,
    lowercase: true
  },
  beginner: [String],
  intermediate: [String],
  advanced: [String],
  quiz: [
    {
      number: Number,
      question: String,
      optionOne: String,
      optionTwo: String,
      optionThree: String,
      optionFour: String,
      answer: String
    }
  ]

})

const skillModel = mongoose.model('skills', skillSchema)
module.exports = {skillModel}
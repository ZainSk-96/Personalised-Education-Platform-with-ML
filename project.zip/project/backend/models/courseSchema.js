const mongoose = require('mongoose')

const courseSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  slug: {
    type: String,
    lowercase: true,
  },
  description: {
    type: String,
    required: true
  },
  instructor: {
    type: String,
    required: true
  },
  category: {
    type: mongoose.ObjectId,
    ref: 'category',
    required: true
  },
  image: {
    data: String,
    contentType: String
  },
  lecture: [{
    number: Number,
    video: String,
    arTitle: String,
    articleExp: String
  }
],
/*
  quizzes: [ {
    qnumber: Number,
    quiz: [{
      question: String,
      optionOne: String,
      optionTwo: String,
      optionThree: String,
      optionFour: String,
      answer: String  
    }]
    Complex Structure
  }
  ],*/
  quiz1: [
    {
      number: Number,
      question: String,
      optionOne: String,
      optionTwo: String,
      optionThree: String,
      optionFour: String,
      answer: String
    }
  ],
  quiz2: [
    {
      number: Number,
      question: String,
      optionOne: String,
      optionTwo: String,
      optionThree: String,
      optionFour: String,
      answer: String
    }
  ],
  enrolledUsers: [
    {
      type: mongoose.ObjectId,
      ref: 'users'
    }
  ]
 /* 
  tags: {
    type: [String],
    default: undefined
  }*/
})

const courseModel = mongoose.model('courses', courseSchema)

module.exports = { courseModel }
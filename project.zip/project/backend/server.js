
const express = require('express')
const dotenv = require('dotenv')
const {connectToDB} = require('./config/database')
const bcrypt = require('bcryptjs')
const cors = require('cors')
// Dummy paths

const fs = require('fs')
const path = require('path')


// Routes Imports 

const {router: authRoute} = require('./routes/authentication.js')
const {router: categoryRoute} = require('./routes/categoryRoute.js')
const {router: courseRoute} = require('./routes/courseRoute.js')
const {router: mlRoute} = require('./routes/machineLearningRoute.js')

//ENV Configuration
dotenv.config()



// Call DataBase Function


// Express App
const app = express()

// MiddleWares
app.use(cors())
app.use(express.urlencoded({extended: false}))
app.use(express.json())


connectToDB();
//Routes with Middleware Functionality
app.use('/api/auth/', authRoute )
app.use('/api/category/', categoryRoute )
app.use('/api/course/', courseRoute)
app.use('/api/ml/', mlRoute)
app.use('/api/images/', express.static(path.join(__dirname, 'routes/uploads')))

/** DUMMY FILES
 * =================
 * For Debugging and may be some file rendering
 * ================
*/

app.get('/register', (req,res) => {
    const register = path.join(__dirname, 'register.html')
    res.sendFile(register)
 // res.send('<form action="/store-user">')
})

app.get('/login', (req,res) => {
    const login = path.join(__dirname, 'login.html')
    res.sendFile(login)
})

/** =========END END  */


app.get('/', (req,res) => {
    res.send('<h1>Hello World</h1>')
})



const port = 4000
app.listen(port, () => {
    console.log('Server is Running on ', port)
})
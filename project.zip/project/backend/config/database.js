const mongoose = require('mongoose')

const MONGO_URL = "mongodb+srv://mongodb:mongodb@cluster0.mdp9ae5.mongodb.net/lms"

const connectToDB = async () => {
    try {
        const connection = await mongoose.connect(MONGO_URL)
        console.log('Connected to Mongo DB Database Successfully')

    } catch (error) {
        console.log(`Error in Database Connectivity ${error}`)
    }
  
}

module.exports = { connectToDB }

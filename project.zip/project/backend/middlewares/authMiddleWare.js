const JWT = require("jsonwebtoken")
const {userModel} = require("../models/userSchema")
const {courseModel} = require("../models/courseSchema")

const SECRET = 'ASDHJaffhdjaAUSHD'

// Protected Route using Tokens

const requireSignIn = async (req,res,next) => {
    try {
        const decode = JWT.verify(req.headers.authorization, SECRET)
    
        req.user = decode
        next()

    } catch (error) {
        console.log(error)
    }
}

const isAdmin = async (req,res,next) => {
    try {
        const user = await userModel.findById(req.user._id)
        if(user.role !== 1) {
            return res.status(401).send({
                success: false,
                message: 'UnAuthorized Access'
            })
        } else {
                next()
        }
        
        
    } catch (error) {
        res.status(401).send({
            success:false,
            message: "Error in Admin Middleware",
            error: error.message
        })
    }
}

const isEnrolled = async (req,res, next) => {
    const userID = req.user._id
    const user = await userModel.findById(req.user._id)
    const role = user.role
    const courseID = req.params.id
    console.log("Auth Course ID", courseID)
    try {
        const course = await courseModel.findById(courseID)
        const enrolled = course.enrolledUsers.includes(userID)
        if (!enrolled && role === 0) {
           return res.status(401).send({
                success: false,
                message: "User Not Enrolled in the selected Course"
            })
        } else {
            req.enrolled
            next()
        }
    } catch (error) {
        console.log(error)
    }
}

module.exports = {requireSignIn, isAdmin, isEnrolled}
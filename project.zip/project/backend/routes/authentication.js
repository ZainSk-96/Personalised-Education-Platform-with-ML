const express = require('express')
const bcrypt = require('bcryptjs')
const JWT = require('jsonwebtoken')
const {requireSignIn, isAdmin} = require('../middlewares/authMiddleWare')

const {userModel} = require('../models/userSchema.js')
const SECRET = 'ASDHJaffhdjaAUSHD' //From ENV

// Router Instance

const router = express.Router()

//Registeration Route

router.post('/register', async (req,res) => {
    

    //console.log(name, email, password)

    const name = req.body.name.trim();
    const email = req.body.email.replace(/ /g, "");
    const password = req.body.password
    const otp = req.body.otp
    console.log(name, email, password, otp)

    try{
       if (name === "" || email === "" || password === "" || otp === "") {
        return res.send("<h1>Not Valid Credentials!</h1>")
    }
 

    const existingUser = await userModel.findOne({email}) 
    if (existingUser) {
        return res.status(200).send({
            success: true,
            message: "User Already Registered, Please Login to Continue"
        })
    }
    
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    const hashedOTP = await bcrypt.hash(req.body.otp, 10);

    const user = await new userModel({name, email, password:hashedPassword, otp: hashedOTP}).save()
    
        
    
     return res.status(201).send({
        success:true,
        message: "User Registered Successfully",
        user
     }
    )
    }
    catch (error){
        return res.status(500).send({
            success: false,
            message: "User Not Registered",
            error: error.message
        
        })
        
    }
    
})


router.post('/login', async (req, res) => {
    try {
    const {email, password} = req.body

    if (email === "" || password === "") {
        return res.status(200).send({
            success: false,
            message: "Invalid Credentials"
        })
    } 

    const existingUser = await userModel.findOne({email})

    if (!existingUser) {

        return res.status(200).send({
            success: false,
            message: "User Not Found"
        })
    }
    const match = await bcrypt.compareSync(req.body.password, existingUser.password)


    if (!match) {
        return res.status(200).send({
            success: false,
            message: "email or password is invalid"
        })
    } 
    // JWT
    const token = await JWT.sign({_id:existingUser._id}, SECRET, {
        expiresIn: "7d",
    })
    res.status(200).send({
        success: true,
        user: {
            name: existingUser.name,
            email: existingUser.email,
            role: existingUser.role,
            interests: existingUser.interests,
            enrolled: existingUser.enrolled
        },
        token: token
        

    })
    
}catch (error) {
        res.status(500).send({
            success: false,
            message: "Login Failed",
            error: error.message
        })
    }

})


router.post('/forgotPassword', async (req,res) => {
    try {
       const {email, otp, newPassword} = req.body
       console.log(email, otp)
        if (!email || !otp || !newPassword) {
            return res.status(201).send({
                success: false,
                message: "Invalid Credentials"
            })
        }

        const user = await userModel.findOne({email})

        if (!user) {
            return res.status(200).send({
                success: false,
                message: "User Not Found"
            })
        }

        const match = await bcrypt.compareSync(req.body.otp, user.otp)

        if (!match) {
            return res.status(200).send(
                {
                    success:false,
                    message: "Invalid Credentials"
                }
            )
        }
        const hashedPassword = await bcrypt.hash(req.body.newPassword, 10)

        await userModel.findByIdAndUpdate(user._id, {password: hashedPassword})


        res.status(200).send({
            success: true,
            message: "Password Updated Successfully"
        })

 

    } catch(error) {
        return res.status(500).send({
            success: false,
            message: "Error in Forgot-Password",
            error: error.message
        })
    }
}) 



router.get('/admin-auth', requireSignIn, isAdmin, (req,res) => {
    res.status(200).send({adAccess: true})
})

router.get('/user-auth', requireSignIn, (req, res) => {
    res.status(200).send({access: true})
})

router.get('/get-user', requireSignIn, async (req,res) => {
    const userID = req.user._id

    const user = await userModel.findById(userID).select('name email enrolledCourses').populate({
        path: 'enrolledCourses.course',
        select: 'name instructor description'    
    }).populate ({
        path: 'skills'
    })

    if(!user) {
        return res.status(404).send({
            success: false,
            message: "User Not Found",
            error: error.message
        })
    }

    res.status(200).send({
        success: true,
        message: "User Fetched Successfully",
        user
    })



})

router.get('/test', requireSignIn, isAdmin ,(req,res) => {
    res.send('Working')
})

// Login Route

module.exports = { router }
const express = require("express")
const mongoose = require('mongoose')
const fs = require("fs")
const path = require("path")
const multer = require("multer")
const slugify = require("slugify")
const { courseModel } = require("../models/courseSchema.js")
const { userModel } = require("../models/userSchema.js")
const {requireSignIn, isAdmin, isEnrolled} = require('../middlewares/authMiddleWare')

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, 'uploads'))
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now()
    const slugFileName = slugify(`${uniqueSuffix} + ${file.originalname}`)
    cb(null, slugFileName)
  }
})

const upload = multer({ storage: storage })

const router = express.Router()

router.post("/create-course",requireSignIn, isAdmin, upload.single("image"),async (req, res) => {
  


  
  const {name, description, instructor, category} = req.body
  const image = req.file

  if (!name || !description || !instructor) {
    return res.status(201).send({
      success: false,
      message: "Invalid Credentials" 
    })
  }
  if (!image) {
    return res.status(201).send({
      success: false,
      message: "Please Upload Image"
    })
  }

  const slug = slugify(name)
  // Added Image Hosting with Static Middlware as follows (see server.js app.use)
  const imageData = `/api/images/${image.filename}` 
  console.log(slug)
  try {

    const createCourse = new courseModel({name,slug,description,instructor,category,
      
      image: {
        data: imageData, //Storing it as Base64 // WE may use direct urls for ease
        contentType: image.mimetype
      }
    })
    
    
    const saveCourse = await createCourse.save()
  
  } catch (error) {
    return res.status(200).send({
      success:false,
      message: "Error in Creating Course",
      error: error.message
    })
  }
  res.status(200).send({
    success:true,
    message: "Course Created Successfully"
  })



 
})

router.get("/getImage", async (req, res) => {
  const id = "656786138c0af1bd18a3cc18"
  const dataStore = await courseModel.findById(id)

  res.send(dataStore.image.data)
})

router.post("/delete-course/:id", requireSignIn, isAdmin, async (req, res) => {
  try {
    const { _id } = req.body;

    if (!_id ) {
      return res.status(200).send({
        success: false,
        message: "Invalid Course Deletion Attempt!",
      });
    }

    const course = await courseModel.findById(_id);
    console.log(_id);

    if (!course) {
      return res.status(201).send({
        success: false,
        message: "Course Not Found to Delete",
      });
    }

    await courseModel.findByIdAndDelete(course._id);
    console.log(`"${course.name}" deleted successfully`);
    res.status(200).send({
      success: true,
      message: "Course Deleted Successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in Creating Course",
      error: error.message
    });
  }
});

router.post("/update-course/:id",requireSignIn, isAdmin, async (req, res) => {

  console.log(req.body)
  try {
    const { _id, lecNum, video, articleExp, arTitle} = req.body;
    const newLecture = {
      number: lecNum,
      video,
      arTitle,
      articleExp
    }

    if (!_id || !lecNum ) {
      return res.status(200).send({
        success: false,
        message: "Invalid Course Id/lecNum!",
      });
    }

    if(!video && (!articleExp || !arTitle)) {
      return res.status(200).send({
        success: false,
        message: "Either Video is Required or Both articleExp and articleExp Title are Required!",
      });
    }

    const course = await courseModel.findById(_id);
    console.log(_id);

    if (!course) {
      return res.status(201).send({
        success: false,
        message: "Course Not Found to Update",
      });
    }

    await courseModel.findByIdAndUpdate({_id}, 
      
      {$push: {lecture: newLecture}},
      {new: true}
      
    );
    console.log(`"${course.name}" Updated successfully`);
    return res.status(200).send({
      success: true,
      message: "Course Updated Successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "Error in Creating Course",
      error: error.message
    });
  }
});

router.post('/initialize-quizzes/:id', requireSignIn, isAdmin, async(req,res) => {
  const quiz1 = {}
  const quiz2 = {}
  try{
    const push = await courseModel.findByIdAndUpdate({_id: req.params.id},
       {
      $push: {
        quiz1: quiz1,
        quiz2: quiz2
        }
      },
      {new: true}
      
      )

    if (!push) {
      console.log("Some Error in Pushing Quiz Initializer")
      return res.status(201).send({
        success: false,
        message: "Error in Initializing Quiz"
      })
    }
    console.log("Successfully Initialized Quizzes")


    res.status(201).send({
      success: true,
      message: "Successfully Initialized Quizzes"
    })

  } catch (error) {
    console.log(error)
    return res.status(500).send({
      success:false,
      message: "Error in Initializing Quizzes"
    })
  }
})

router.get('/get-quiz-for-update/:id', requireSignIn, isAdmin, async(req,res) => {
  console.log(req.user._id, req.params.id)

  try {
    const course = await courseModel.findOne({_id: req.params.id}).select("quiz1 quiz2 name");

    if (!course) {
      return res.status(200).send({
        success: false,
        message: "No Course Found",
      });
    }


    console.log(course)
    res.status(200).send({
      success: true,
      message: "Course Loaded Successfully",
      course,
    })
  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "Error in Loading Course",
      error: error.message
    })
  }
})

router.post('/create-quiz-question/:id',requireSignIn,isAdmin, async (req,res) => {
  console.log('Request Quiz Creation Data: ', req.body)

  try {
  const {courseID, quizID, question, optionOne, optionTwo, optionThree, optionFour, number, answer} = req.body

    const newQuestion = {
      number,
      question,
      optionOne,
      optionTwo,
      optionThree,
      optionFour,
      answer
    }

    /*console.log(newQuestion)*/

    if (!question || !optionOne || !optionTwo || !optionThree || !optionFour || !answer ) {
      return res.status(201).send({
        success: false,
        message: "Invaid or Missing Option",
      });
    }


    const course = await courseModel.findOne({_id: courseID}).select('name');


    if (!course) {
      return res.status(201).send({
        success: false,
        message: "Course Not Found to Update",
      });
    }

    if(quizID === 'Mid') {
      const quizObject = await courseModel.findById(courseID).select('quiz1 -_id')

      const quizLength = quizObject.quiz1.length
      if (quizLength >= 10) {
        return res.status(409).send({
          success: false,
          message: "Maximum Questions Are Already Submitted for Final Quiz"
        })
      } else {
        await courseModel.findByIdAndUpdate({_id: courseID}, 
          {
            $push: {
              quiz1: newQuestion
           }
          },
          {new: true}   
        )
      }
    }
    if(quizID === 'Final') {
      const quizObject = await courseModel.findById(courseID).select('quiz2 -_id')
      const quizLength = quizObject.quiz2.length

      if (quizLength >= 10) {
        return res.status(409).send({
          success: false,
          message: "Maximum Questions Are Already Submitted for Final Quiz"
        })
      } else { 
        await courseModel.findByIdAndUpdate({_id: courseID}, 
          {
            $push: {
              quiz2: newQuestion
           }
          },
          {new: true}   
        )
      }
    }

  
    console.log(`"${course.name}" New Quiz Added successfully`);
    return res.status(200).send({
      success: true,
      message: "New Quiz Added Successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "Error in Creating Course",
      error: error.message
    });
  }

})


router.post('/delete-quiz-question/:id',requireSignIn,isAdmin, async (req,res) => {

  console.log(req.body)
  try {
  const {questionID, quizID, courseID} = req.body


    if (!questionID || !quizID || !courseID ) {
      return res.status(201).send({
        success: false,
        message: "Invaid or Missing ID's to delete",
      });
    }


    const course = await courseModel.findOne({_id: courseID}).select('name');


    if (!course) {
      return res.status(201).send({
        success: false,
        message: "Course Not Found to Update",
      });
    }

    if (quizID === 'Mid') {
      await courseModel.findByIdAndUpdate({_id: courseID}, 
        {
          $pull: {
            quiz1: {_id: questionID}
         }
        }   
      )
    }
    if (quizID === 'Final') {
      await courseModel.findByIdAndUpdate({_id: courseID}, 
        {
          $pull: {
            quiz2: {_id: questionID}
         }
        }
      )
    }
  
    console.log(`"${course.name}" Question Deleted successfully`);
    return res.status(200).send({
      success: true,
      message: "Question Deleted Succesfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "Error in Creating Course",
      error: error.message
    });
  }

})

router.post('/submit-quiz/:id', requireSignIn, isEnrolled, async(req,res) => {
  console.log(req.body, req.params.id)

  console.log("SubmitQuiz: Params ID", req.params.id)
  let getQuiz;
  let rightanswers;
  try {
    const {answers, quizID} = req.body
    const courseID = req.params.id
    console.log("Submit Quiz: Course ID: ", courseID)
    if (quizID === 'Mid') {
     getQuiz = await courseModel.findOne({_id: req.params.id}).select('quiz1.answer')
      rightAnswers = getQuiz.quiz1.map((element) => element.answer)
    } else if (quizID === 'Final') {
     getQuiz = await courseModel.findOne({_id: req.params.id}).select('quiz2.answer')
     rightAnswers = getQuiz.quiz2.map((element) => element.answer)
    
    } else {
      return res.status(404).send({
        success: false,
        message: 'No Such Quiz Found'
      })
    }

  
    if(!getQuiz) {
      return res.status(404).send({
        success: false,
        message: "No Quiz Found"
      })
    }

  let sum = 0;

  for (let value of answers) {
    if (rightAnswers.includes(value)) {
      sum += 1;
    }
  }
  console.log(sum)

  // Making Query for Quiz Schema
   let quizNumber;
   if (quizID === 'Mid') {
    const result = await userModel.updateOne({
      _id: req.user._id, 
      'enrolledCourses.course': courseID
     },
     {
      $set: {
       'enrolledCourses.$.quiz1': sum
      }
     }
     )
    console.log('Result should be shown Here, ', result)

   } else if (quizID === 'Final') {
    const result = await userModel.updateOne({
      _id: req.user._id, 
      'enrolledCourses.course': courseID
     },
     {
      $set: {
        'enrolledCourses.$.quiz2': sum
      }
     }
     )
    console.log(result)

   }
/*
    const result = await userModel.findOneAndUpdate({_id: req.user._id, 'enrolledCourses.course': mongoose.Types.ObjectId(courseID)},
   {$set: {[`enrolledCourses.$.${quizNumber}`]: sum}},
   {new: true}
    ) */
   
/*
    const result = await userModel.findById(req.user._id).select({
      enrolledCourses: {
        $elemMatch: {course: courseID}
      }
    }) */

    res.status(201).send({
      success: true,
      message: "Submitted Quiz Successfully"
    })

  } catch (error) {
    return res.status(500).send({
      success: false,
      message: "Error in Submitting Quiz Result"
    })
  }
})

router.get('/generate-certificate/:id', requireSignIn, isEnrolled, async(req,res) => {
  try {
    const courseID = req.params.id
    const userID = req.user._id
    console.log(courseID, userID)
    if (!courseID || !userID) {
      return res.status(404).send({
        success: false,
        message: "User or CourseID not found"
      })
    }
    const enrolledCourseDetails = await userModel.findOne({
      _id: userID,
      'enrolledCourses.course': courseID
    }, {
      'enrolledCourses.$': 1
    }    
    )

    const {quiz1, quiz2, transcript, status, certificate} = enrolledCourseDetails.enrolledCourses[0]
    console.log(quiz1)

    const addResults = quiz1 + quiz2

    if (addResults <= 15) {
    const response = await userModel.updateOne({
      _id: req.user._id, 
      'enrolledCourses.course': courseID
     },
     {
      $set: {
       'enrolledCourses.$.transcript': addResults
      }
     }
     )
     console.log(response)
     return res.status(201).send({
      success: false,
      message: 'Transcript is Incomplete and Result is Less than 15'
     })
    } else if (addResults > 15) {
      const response = await userModel.updateOne({
        _id: req.user._id, 
        'enrolledCourses.course': courseID
       },
       {
        $set: {
         'enrolledCourses.$.transcript': addResults,
         'enrolledCourses.$.status': true,
         'enrolledCourses.$.certificate': true
        }
       }
       )
      console.log(response)
    }
    res.status(200).send({
      success: true,
      message: 'Certificate is Generated Successfully',
    })

  } catch (error) {
    return res.status(500).send({
      success: fales,
      message: 'Error in Getting Enrolled Course Details',
      error: error.message
    })
  }
})

/*
router.get('/get-quiz-for-update/:id', requireSignIn, isAdmin, async(req,res) => {
  console.log(req.user._id, req.params.id)

  try {
    const course = await courseModel.findOne({_id: req.params.id}).select("quizzes name");

    if (!course) {
      return res.status(200).send({
        success: false,
        message: "No Course Found",
      });
    }

    const quizzes = course.quizzes

    console.log(quizzes)

    res.status(200).send({
      success: true,
      message: "Course Loaded Successfully",
      course,
      quizzes
    })
  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "Error in Loading Course",
      error: error.message
    })
  }
})

router.post('/add-quiz/:id',requireSignIn,isAdmin, async (req,res) => {

  const {number, courseID} = req.body

  try {

    if (!number || !courseID) {
      return res.status(201).send({
        success: false,
        message: "Invalid Quiz Number/CourseID"
      })
    }
    const course = await courseModel.findOne({_id: courseID}).select('name quiz')

    if (!course) {
      return res.status(201).send({
        success: false,
        message: "No Such Course Found, Please use valid course ID"
      })
    }

    await courseModel.findByIdAndUpdate({_id: courseID}, 
      
      {$push: {
        quizzes: {
          qnumber: number
        } 
      }},
      {new: true}
      
    );
    res.status(200).send({
      success:true,
      message: "Successfully Added New Quiz to the course"
    })
  } catch (error) {
    return res.status(500).send({
      success: false,
      message: "Error in Adding Quiz",
      error: error.message
    })
  }

})

router.post('/create-quiz-question/:id',requireSignIn,isAdmin, async (req,res) => {
  console.log('Request Quiz Creation Data: ', req.body)

  try {
  const {courseID, quizID, question, optionOne, optionTwo, optionThree, optionFour, number, answer} = req.body

    const newQuestion = {
      number,
      question,
      optionOne,
      optionTwo,
      optionThree,
      optionFour,
      answer
    }

    if (!question || !optionOne || !optionTwo || !optionThree || !optionFour || !answer ) {
      return res.status(201).send({
        success: false,
        message: "Invaid or Missing Option",
      });
    }


    const course = await courseModel.findOne({_id: courseID}).select('name');


    if (!course) {
      return res.status(201).send({
        success: false,
        message: "Course Not Found to Update",
      });
    }

    await courseModel.findByIdAndUpdate({_id: courseID}, 
      
      {
        $push: {
        'quizzes.$[quiz].quiz': newQuestion
       }
      },
      {new: true,
        arrayFilters: [{'quiz._id': quizID}]
      }
     
      
    );
    console.log(`"${course.name}" New Quiz Added successfully`);
    return res.status(200).send({
      success: true,
      message: "New Quiz Added Successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "Error in Creating Course",
      error: error.message
    });
  }

})
*/

router.get("/all-courses", async (req, res) => {

  const {reqData} = req.query
  try {
    const courses = await courseModel
      .find({})
      .select(reqData)
      .limit(12)
      .sort({ createdAt: -1 });

    if (!courses) {
      return res.status(200).send({
        success: false,
        message: "No Courses Found",
      });
    }
    res.status(200).send({
      success: true,
      message: "Courses Loaded Successfully",
      countTotal: courses.length,
      courses,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "Error in Creating Course",
      error: error.message,
    });
  }
});

router.get("/get-courses-for-home", async (req, res) => {
 
  try {
    const courses = await courseModel
      .find({})
      .select("name description instructor image category")
      .limit(6)
      .sort({ createdAt: -1 });

    if (!courses) {
      return res.status(200).send({
        success: false,
        message: "No Courses Found",
      });
    }
    res.status(200).send({
      success: true,
      message: "Courses Loaded Successfully",
      countTotal: courses.length,
      courses,
    });
  } catch (error) {
    console.log(error);
   return res.status(500).send({
      success: false,
      message: "Error in Creating Course",
      error: error.message,
    });
  }
});



router.get("/get-course/:id", requireSignIn, isEnrolled, async (req, res) => {

    console.log(req.user._id, req.params.id)

  try {
    const course = await courseModel.findById(req.params.id);

    if (!course) {
      return res.status(200).send({
        success: false,
        message: "No Course Found",
      });
    }

    res.status(200).send({
      success: true,
      message: "Course Loaded Successfully",
      course
    })
  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "Error in Loading Course",
      error: error.message
    })
  }
})

// Course Details Page Show to Everyone

router.get("/get-course-details/:id", async (req, res) => {

  console.log(req.params.id)

try {
  const course = await courseModel.findById(req.params.id).select("name description instructor category image");

  if (!course) {
    return res.status(200).send({
      success: false,
      message: "No Course Found",
    });
  }

  res.status(200).send({
    success: true,
    message: "Course Loaded Successfully",
    course,
  })
} catch (error) {
  console.log(error);
  res.status(500).send({
    success: false,
    message: "Error in Loading Course",
    error: error.message
  })
}
})

// Enroll User in Course 

router.post('/enroll-user/:id', requireSignIn, async (req, res) => {



/*
try {
  const alreadyEnrolled = await courseModel.findOne({
    _id: courseID,
    enrolledUsers: {$in: [mongoose.ObjectId(userID)]}
  }).select('enrolledUsers')

  if(alreadyEnrolled) {
    return res.status(200).send({
      success: false,
      message: "User Already Enrolled"
    })
  }

  console.log(alreadyEnrolled)

  await courseModel.findByIdAndUpdate({_id: courseID}, 
      
    {$push: {enrolledUsers: mongoose.ObjectId(userID)}},
    {new: true}
    
  )
  console.log("User Registered Successfully")

  res.status(200).send({
    success: true,
    message: "Successfully Enrolled"
  }) */

  try {
      const courseID = req.params.id
      const userID = req.user._id
      console.log(courseID, userID)
  
      const course = await courseModel.findOne({_id: courseID})
     
      if (!course) {
        return res.status(404).send({
          success:false,
          message: "No such Course Found"
        })
      }
      const isAlreadyEnrolled = course.enrolledUsers.includes(userID)
      console.log(isAlreadyEnrolled)
      if (isAlreadyEnrolled) {
        return res.status(200).send({
          success: false,
          message: "User Already Enrolled"
        })
      }

      course.enrolledUsers.push(userID)
      await course.save()

      
      const user = await userModel.findById(userID)

      const AlreadyEnrolled = user.enrolledCourses.some(element => element.course.equals(courseID))

      if(AlreadyEnrolled) {
        console.log("User Already have Course Saved in Enrolled!")
        return res.status(422).send({
          success: false,
          message: "User Already have Course Saved"
        })
      }

     user.enrolledCourses.push(
        {course: courseID}
      )
     await user.save()
      res.status(200).send({
        success: true,
        message: "Successfully Enrolled"
      })

} catch (error) {
  console.log("Enrollment Error", error)
  res.status(500).send( {
    success: false,
    message: "Error in Enrollment",
    error: error.message
  })
}
})

router.post('/unenroll-user/:id', requireSignIn, isEnrolled, async (req, res) => {




 
   try {
    const courseID = req.params.id
    const userID = req.user._id
    console.log(courseID, userID)
   
       const course = await courseModel.findOne({_id: courseID})
      
       if (!course) {
         return res.status(404).send({
           success:false,
           message: "No such Course Found"
         })
       }

       course.enrolledUsers.pull(userID)
       await course.save()
       
       // Unenrolling From User

       const user = await userModel.findById(userID)

       const AlreadyEnrolled = user.enrolledCourses.some(element => element.course.equals(courseID))
 
       if(!AlreadyEnrolled) {
         console.log("User Not Enrolled in Selected Course!")
         return res.status(422).send({
           success: false,
           message: "Not Enrolled"
         })
       }
 
      user.enrolledCourses.pull(
         {course: courseID}
       )
      await user.save()
  res.status(200).send({
    success: true,
    message: "Successfully UnEnrolled user from Course"
   })
 
 } catch (error) {
  console.log("UnEnroll Error", error)
   res.status(500).send( {
     success: false,
     message: "Error in Enrollment",
     error: error.message
   })
 }
 })
// Use this in certificate Area too
 router.get('/get-user-enrolled-course/:id', requireSignIn, isEnrolled, async (req, res) => {
  try {
    const courseID = req.params.id
    const userID = req.user._id
    if (!courseID || !userID) {
      return res.status(404).send({
        success: false,
        message: "User or CourseID not found"
      })
    }
    const enrolledCourseDetails = await userModel.findOne({
      _id: userID,
      'enrolledCourses.course': courseID
    }, {
      'enrolledCourses.$': 1
    }    
    )

    const enrolledCourse = enrolledCourseDetails.enrolledCourses[0]
    console.log(enrolledCourse)
    res.status(200).send({
      success: true,
      message: 'Enrolled Course Details Sent Successfully',
      enrolledCourse
    })
  } catch (error) {
    return res.status(500).send({
      success: false,
      message: 'Error in Getting Enrolled Course Details',
      error: error.message
    })
  }
 })

/**Model.count().exec(function(err, count){

  var random = Math.floor(Math.random() * count);

  Model.findOne().skip(random).exec(
    function (err, result) {

      // result is random 

  });

}); */

module.exports = { router }

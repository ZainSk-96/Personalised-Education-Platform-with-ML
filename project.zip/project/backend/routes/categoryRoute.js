const express = require('express')
const {categoryModel} = require('../models/categorySchema')
const slugify = require('slugify')
const mongoose = require('mongoose')

const router = express.Router()

router.post('/create-category', async (req, res) => {

  try {
    const {name} = req.body
    if(!name) {
      return res.status(401).send("Name is Required")
    }
    const existingCategory = await categoryModel.findOne({name})
    if (existingCategory) {
      return res.status(200).send({
        success: false,
        message: "Category Already Exists"
      })
    }
    const category = await new categoryModel({name, slug: slugify(name)}).save()
    res.status(201).send({
      success: true,
      message: "Category Created Successfully"
    })
    
  } catch (error) {
    console.log(error)
    res.status(500).send({
      success: false,
      message: "Error in Creating Category",
      error: error.message
    })
  }

})

//router.post('/get-category/:._id',)

router.post('/delete-category/:id', async (req, res) => {
  try {

    const {_id} = req.body

    console.log(_id)

    const category = await categoryModel.findById(_id)

    console.log(category)

    if (!category) {
      return res.status(401).send({
        success: false,
        message: "Not Valid Category"
      })
    }
    await categoryModel.findByIdAndDelete(category._id)
    res.status(200).send({
      success: true,
      message: "Category Deleted Successfully"
    })

  } catch (error) {
    console.log(error)
    res.status(500).send({
      success: false,
      message: "Error in Deleting Category",
      error: error.message
    })
  }
})

router.get("/categories", async (req, res) => {
  try {
    
    const categories = await categoryModel.find({})

    if(!categories) {
      return res.status(401).send({
        success: false,
        message: "No Categories Defined"
      })
    }

    res.status(200).send(
      {
        success: true,
        message: "Categories Sent Successfully",
        categories
    }
      )

  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Error in Getting Categories",
      error: error.message
    })
  }
})

router.get("/s-category/:id", async (req, res) => {
  try {
    const {slug} = req.params

    const category = await categoryModel.findOne({slug})

    if(!category) {
      return res.status(401).send({
        success: false,
        message: "No Category Defined"
      })
    }

    res.status(200).send(category)

  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Error in Getting Categories",
      error: error.message
    })
  }
})
module.exports = { router }
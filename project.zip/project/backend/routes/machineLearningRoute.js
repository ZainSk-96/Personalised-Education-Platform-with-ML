const express = require('express')
const {userModel} = require('../models/userSchema.js')
const {courseModel} = require('../models/courseSchema.js')
const {skillModel} = require('../models/skillSchema.js')
const {requireSignIn, isAdmin, isEnrolled} = require('../middlewares/authMiddleWare')
const slugify = require('slugify')



const router = express.Router()


router.post('/set-interest', requireSignIn, async (req, res) => {
 
  try {
    const userID = req.user._id
    const {interestID } = req.body

    const user = await userModel.findById(userID)
    if(!user) {
      console.log("User Not Found")
      return res.status(404).send({
          success: false,
          message:"User Not Found"
        }
      )
    }

    const existingInterest = user.userInterests.includes(interestID)

    if (existingInterest) {
      console.log("Interest Already Added")
      return res.status(422).send({
        success: false,
        message:"Interest Already Added"
      }
      )
    }

    user.userInterests.push(interestID)
    await user.save()

    res.status(201).send({
      success: true,
      message: "User Added Successfully"
    })
  } catch (error) {
    res.status(500).send({
      success:false,
      message: "Error in Adding Interest"
    })
  }


}) 
router.post('/delete-interest', requireSignIn, async (req,res) => {

  try {
    const userID = req.user._id
    const { interestID } = req.body

    const user = await userModel.findById(userID)
    if(!user) {
      console.log("User Not Found")
      return res.status(404).send({
          success: false,
          message:"User Not Found"
        }
      )
    }

    const existingInterest = user.userInterests.includes(interestID)

    if (!existingInterest) {
      console.log("Interest Not Found to Delete")
      return res.status(422).send({
        success: false,
        message:"No Interest found to delete"
      }
      )
    }

    user.userInterests.pull(interestID)
    await user.save()

    res.status(201).send({
      success: true,
      message: "User Added Successfully"
    })
  } catch (error) {
    res.status(500).send({
      success:false,
      message: "Error in Adding Interest",
      error: error.message
    })
  }

}) 

router.get('/get-interests', requireSignIn, async(req,res) => {
  try {
    const userID = req.user._id
    const user = await userModel.findById(userID).populate('userInterests')

    if (!user) {
      console.log("User Not Found")
      return res.status(404).send({
        success: false,
        message: "User Not Found"
      })
    }

    const interests = user.userInterests

    res.status(200).send({
      success: true,
      message: "Interests Fetched Successfully",
      interests
    })

  } catch(error) {
    res.status(500).send({
      success: false,
      message: "Error in Getting Interests",
      error: error.message
    })
  }
  
})

// Make Recommendation System Here , with use of Search API

router.get('/recommendations', requireSignIn, async (req,res) => {
    
  try {
    const userID = req.user._id
    const interests = await userModel.findById(userID).select('userInterests -_id').populate('userInterests')

    if(!interests) {
      console.log("No Interest Found")
      return res.status(404).send({
        success: false,
        message: "No Interest Found",
        error: error.message
      })
    }

    const userCategories = interests.userInterests.map((element) => element._id)

    const courses = await courseModel.aggregate([
      {$match: {category: {$in: userCategories}}},
      {$sample: {size: 2}},
      {$project: {name: 1, instructor: 1, description: 1, category: 1}}
    ])
    

    console.log(courses)
    res.status(200).send({
      success: true,
      message: "Recommendations Sent Successfully",
      courses
    })

  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Error in Recommendations",
      error: error.message
    })
  }

})

// Section 2:Skills Assessment - Learning Pathways

// ------------------ADMIN MANAGEMENT ROUTES START -------------------


router.post('/create-skill', requireSignIn, isAdmin, async (req, res) => {

  try {
    const {name, beginner, intermediate, advanced, quiz} = req.body

    const slug = slugify(name)
    // beginner, intermediate , advanced must be array
    // May be I will implement quiz on the same page but Will see in the end
    if (
      !name || 
      !Array.isArray(beginner) || 
      beginner.length === 0 || 
    !Array.isArray(intermediate) || 
    intermediate.length === 0 || 
    !Array.isArray(advanced) || advanced.length ===0
    ) {
      return res.status(401).send("Please Enter Valid Fields")
    }
    const existingSkill = await skillModel.findOne({slug})
    if (existingSkill) {
      return res.status(200).send({
        success: false,
        message: "Skill Already Exists"
      })
    }
    const skill = await new skillModel({name, slug, beginner, intermediate, advanced}).save()
    res.status(201).send({
      success: true,
      message: "Skill Created Successfully"
    })
    
  } catch (error) {
    console.log(error)
    res.status(500).send({
      success: false,
      message: "Error in Creating Category",
      error: error.message
    })
  }

})

router.post('/delete-skill/:id', requireSignIn, isAdmin, async (req, res) => {
  try {

    const {_id} = req.body

    console.log(_id)

    const skill = await skillModel.findById(_id)

    console.log(skill)

    if (!skill) {
      return res.status(401).send({
        success: false,
        message: "Not Valid Skill"
      })
    }
    await skillModel.findByIdAndDelete(skill._id)
    res.status(200).send({
      success: true,
      message: "Skill Deleted Successfully"
    })

  } catch (error) {
    console.log(error)
    res.status(500).send({
      success: false,
      message: "Error in Deleting Skill",
      error: error.message
    })
  }
})

router.get("/get-skills-names", requireSignIn, async (req, res) => {
  try {
    
    const skills = await skillModel.find({}).select('name slug')

    if(!skills) {
      return res.status(401).send({
        success: false,
        message: "No skills Defined"
      })
    }

    res.status(200).send(
      {
        success: true,
        message: "skills Sent Successfully",
        skills
    }
      )

  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Error in Getting skills",
      error: error.message
    })
  }
})

// ==================== Skill Quiz (Admin Section) ================

router.post('/create-skill-quiz-question/:id',requireSignIn,isAdmin, async (req,res) => {
  
  
  console.log('Request Quiz Creation Data: ', req.body)

  try {
  const {skillID, quizID, question, optionOne, optionTwo, optionThree, optionFour, number, answer} = req.body

    const newQuestion = {
      number,
      question,
      optionOne,
      optionTwo,
      optionThree,
      optionFour,
      answer
    }

    /*console.log(newQuestion)*/

    if (!skillID || !question || !optionOne || !optionTwo || !optionThree || !optionFour || !answer ) {
      return res.status(201).send({
        success: false,
        message: "Invaid or Missing Option",
      });
    }


    const skill = await skillModel.findOne({_id: skillID}).select('name');

    if (!skill) {
      return res.status(201).send({
        success: false,
        message: "Skill Not Found to Update",
      });
    }

    console.log('Skill Loaded for Updating Quiz: ', skill)


      const quizObject = await skillModel.findById(skill._id).select('quiz -_id')

      const quizLength = quizObject.quiz.length

      if (quizLength >= 10) {
        return res.status(409).send({
          success: false,
          message: "Maximum Questions Are Already Submitted for Skill Quiz"
        })
      } else {
        await skillModel.findByIdAndUpdate({_id: skillID}, 
          {
            $push: {
              quiz: newQuestion
           }
          },
          {new: true}   
        )
      }
  
    

  
    console.log(`"${skill.name}" New Quiz Added successfully`);
    return res.status(200).send({
      success: true,
      message: "New Quiz Added Successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "Error in Creating Course",
      error: error.message
    });
  }

})


router.post('/delete-quiz-question/:id',requireSignIn,isAdmin, async (req,res) => {

  console.log(req.body)
  try {
  const {questionID, skillID} = req.body


    if (!questionID || !skillID ) {
      return res.status(201).send({
        success: false,
        message: "Invaid or Missing ID's to delete",
      });
    }


    const skill = await skillModel.findOne({_id: skillID}).select('name');


    if (!skill) {
      return res.status(201).send({
        success: false,
        message: "skill Not Found to Update",
      });
    }


      await skillModel.findByIdAndUpdate({_id: skillID}, 
        {
          $pull: {
            quiz: {_id: questionID}
         }
        }   
      )

    console.log(`"${skill.name}" Question Deleted successfully`);
    return res.status(200).send({
      success: true,
      message: "Question Deleted Succesfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "Error in Creating skill",
      error: error.message
    });
  }

})

// ==================== Skill Quiz (Admin Section) =================

// ==================== Skill Getters (Admin/User) =================

router.get('/get-skill/:id', requireSignIn, async (req,res) => {
  try {
   const skillID = req.params.id

   console.log(skillID)

    if (!skillID) {
      console.log('No Skill ID Provided to Get in /get-skill')
      return res.status(400).send({
        success: false,
        message: "No Skill ID Provided"
      })
    }

    const skill = await skillModel.findById(skillID)

    if (!skill) {
      console.log('No Found in /get-skill')
      return res.status(200).send({
        success: false,
        message: "No Skill Found with Provided ID"
      })
    }

    console.log(skill)

    res.status(200).send({
      success: true,
      message: "Successfully Sent A Single Skill to Request",
      skill
    })


  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "Error in Fetching Single Skill",
      error: error.message
    })
  }
})

// ==================== Skill Getters (Admin/User) =================

// ------------------ADMIN MANAGEMENT ROUTES END -------------------

// --------------------USER MANAGEMENT ROUTES-----------------------

router.post('/set-skill/:id', requireSignIn, async (req, res) => {
 
  try {
    const userID = req.user._id
    const {skillID} = req.body

    const user = await userModel.findById(userID)
    if(!user) {
      console.log("User Not Found")
      return res.status(404).send({
          success: false,
          message:"User Not Found"
        }
      )
    }
    console.log('Skill ADDING USER ', user)
    const existingSkill = user.skills.some((element) => element.skill?.equals(skillID))

    if (existingSkill) {
      console.log("Skill Already Selected")
      return res.status(422).send({
        success: false,
        message:"Skill Already Added"
      }
      )
    }

    user.skills.push({skill: skillID})
    await user.save()

    res.status(201).send({
      success: true,
      message: "User Added Successfully"
    })
  } catch (error) {
    res.status(500).send({
      success:false,
      message: "Error in Adding Interest",
      error: error.message
    })
  }


}) 

router.get('/get-skill-quiz/:id', requireSignIn, async (req,res) => {
  try {
   const skillID = req.params.id

   console.log(skillID)

    if (!skillID) {
      console.log('No Skill ID Provided to Get in /get-skill')
      return res.status(400).send({
        success: false,
        message: "No Skill ID Provided"
      })
    }

    const quiz = await skillModel.findById(skillID).select('quiz name')

    if (!quiz) {
      console.log('No Found in /get-skill-quiz')
      return res.status(200).send({
        success: false,
        message: "No Skill Found with Provided ID"
      })
    }

    console.log(quiz)


  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "Error in Fetching Single Skill",
      error: error.message
    })
  }
})

router.get('/get-skill-result/:id', requireSignIn, async(req,res) => {
  try {
    const skillID = req.params.id
 
    console.log(skillID)
 
     if (!skillID) {
       console.log('No Skill ID Provided to Get in /get-skill')
       return res.status(400).send({
         success: false,
         message: "No Skill ID Provided"
       })
     }
 
     const skillResult = await userModel.findOne(
       {_id: req.user._id, 'skills.skill': skillID},
       {'skills.$': 1}
     )
 
     if (!skillResult) {
       console.log('No Found in /get-skill-quiz')
       return res.status(200).send({
         success: false,
         message: "No such Skill Found in User's Provided ID"
       })
     }
 
     const userResult = skillResult.skills
     res.status(200).send({
       success: true,
       message: "Successfully Sent A Single Skill QUIZ to Request",
       userResult
     })
 
 
   } catch (error) {
     console.log(error);
     return res.status(500).send({
       success: false,
       message: "Error in Fetching Single Skill",
       error: error.message
     })
   }
})

router.get('/get-my-skills', requireSignIn, async (req,res) => {


  try {
    const userID = req.user._id

    if (!userID) {
      return res.status(400).send({
        success: false,
        message: "Bad User ID Provided"
      })
    }

    const userSkills = await userModel.findById(userID).select('skills -_id').populate('skills.skill')

    if (!userSkills) {
      return res.status(404).send({
        success: false,
        message: "User Has no Skills Added!"
      })
    }

    console.log("User Skills:", userSkills)

    res.status(200).send({
      success: true,
      message: "User Skills Sent Successfully",
      userSkills
    })
  } catch (error) {
    res.status(500).send({
      success: true,
      message: "Server: Error in Completing Request"
    })
  }
})

// --------------------USER MANAGEMENT ROUTES END -----------------------

// -------------------- Learning Path Way Artificial Intelligence --------------


// -------------------- Submit Quiz From User Side -----------------------

router.post('/submit-skill-quiz/:id', requireSignIn, async(req,res) => {
  console.log(req.body, req.params.id)
  let getQuiz;
  let rightanswers;
  try {
    const {courseID, answers, quizID} = req.body

    const skillID = quizID

    if (!answers || !quizID) {
      return res.status(400).send({
        success: false,
        message: "Not Valid ID's Provided"
      })
    }
    getQuiz = await skillModel.findOne({_id: skillID}).select('quiz.answer')
    rightAnswers = getQuiz.quiz.map((element) => element.answer)

  
    if(!getQuiz) {
      return res.status(404).send({
        success: false,
        message: "No Quiz Found"
      })
    }

  let sum = 0;

  for (let value of answers) {
    if (rightAnswers.includes(value)) {
      sum += 1;
    }
  }
  console.log('Quiz Results',sum)

  if (sum < 0 || sum > 10) {
    return res.status(422).send({
      success: false,
      message: "Bad Result, Something Wrong in the Request"
    })
  }

  // Making Query for Quiz Schema
  let skillLevel;
    if (sum < 4) {
      skillLevel = 'beginner'
    } else if (sum >= 4 && sum < 8) {
      skillLevel = 'intermediate'
    } else {
      skillLevel = 'advanced'
    }

    console.log(skillLevel, skillID)

  const result = await userModel.findByIdAndUpdate(
    {_id: req.user._id},
    {
      'skills.$[element].score': sum,
      'skills.$[element].level': skillLevel
    },
    { 
      arrayFilters: [{'element.skill': skillID}],
      new: true
    }
    )

    console.log(result)

    res.status(201).send({
      success: true,
      message: "Submitted Quiz Successfully"
    })

  } catch (error) {
    return res.status(500).send({
      success: false,
      message: "Error in Submitting Quiz Result"
    })
  }
}) 


// -------------------------- Learning Pathway Module ----------------

router.get('/get-learning-pathway', requireSignIn, async (req,res) => {

  try {
    const userID = req.user._id

    if (!userID) {
      return res.status(400).send({
        success: false,
        message: "Bad User ID Provided"
      })
    }

    const userSkills = await userModel
    .findById(userID)
    .select('skills -_id')
    .populate({
      path: 'skills.skill',
      select: 'name level score beginner intermediate advanced'
    })
  

    if (!userSkills) {
      return res.status(404).send({
        success: false,
        message: "User Has no Skills Added!"
      })
    }

    console.log("User Skills:", userSkills)

    res.status(200).send({
      success: true,
      message: "User Skills Sent Successfully",
      userSkills
    })
  } catch (error) {
    res.status(500).send({
      success: true,
      message: "Server: Error in Completing Request"
    })
  }
})

module.exports = {router}




import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./components/context/AuthContext.jsx";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Home from "./components/Home.jsx";
import Header from "./components/Header.jsx";
import Login from "./components/Login.jsx";
import Profile from "./components/Profile.jsx";
import Footer from "./components/Footer.jsx";
import Signup from "./components/Signup.jsx";
import ForgotPassword from "./components/ForgotPassword.jsx";
import Assignments from "./components/Assignments.jsx"
import AllCourses from "./components/AllCourses.jsx"
import PrivateRoute from "./components/Routes/Private.jsx"
import AdminPrivate from './components/Routes/AdminPrivate.jsx'
import AdminDashboard from './components/admin/AdminDashboard.jsx'
import CreateCourse from './components/admin/CreateCourse.jsx'
import UpdateCourse from './components/admin/UpdateCourse.jsx'
import UpdateSkill from './components/admin/UpdateSkill.jsx'
import UpdateQuiz from './components/admin/UpdateQuiz.jsx'
import CreateCategory from './components/admin/CreateCategory.jsx'
import CreateSkill from './components/admin/CreateSkill.jsx'
import MyInterests from './components/user/MyInterests.jsx'
import MyCertificates from './components/user/MyCertificates.jsx'
import MyCourses from './components/user/MyCourses.jsx'
import Course from './components/courses/Course.jsx'
import CourseDetails from './components/courses/CourseDetails.jsx'
import UserProfile from './components/user/UserProfile.jsx'
import SkillAssessment from './components/user/SkillAssessment.jsx'
import NotFound from './components/NotFound.jsx'


function App() {
  return (
    <AuthProvider>

      <Router>
        <div className="flex flex-col min-h-screen">
          <Header />
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route path="/course-details/:id" element={<CourseDetails />} />
            <Route path="/dashboard" element={<PrivateRoute />}> 
              <Route path="user/profile" element={<UserProfile />} />
              <Route path="user/my-interests" element={<MyInterests />} />
              <Route path="user/my-courses" element={<MyCourses />} />
              <Route path="user/course/:id" element={<Course />} />
              <Route path="user/my-certificates" element={<MyCertificates />} />
              <Route path="user/skill-assessment" element={<SkillAssessment/>} />
            </Route>
            <Route path="/dashboard" element={<AdminPrivate />}>
              <Route path="admin" element={<AdminDashboard />} />
              <Route path="admin/create-course" element={<CreateCourse />} />
              <Route path="admin/update-course/:id" element={<UpdateCourse />} />
              <Route path="admin/update-quiz/:id" element={<UpdateQuiz />} />
              <Route path="admin/create-category" element={<CreateCategory />} />
              <Route path="admin/create-skill" element={<CreateSkill />} />
              <Route path="admin/update-skill/:id" element={<UpdateSkill />} />

            </Route>
            
            <Route path="/assignments" element={<Assignments />} />
            <Route path="/courses" element={<AllCourses />} />
            <Route path="/Login" element={<Login />} />
            <Route path="/Signup" element={<Signup />} />
            <Route path="/ForgotPassword" element={<ForgotPassword />} />
            <Route path="/Profile" element={<Profile />} />
            <Route element={<NotFound />}/>
          </Routes>
          <Footer />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;

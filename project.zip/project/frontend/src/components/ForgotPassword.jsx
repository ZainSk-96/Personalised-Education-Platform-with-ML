import React, { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import Sidebar from "./Sidebar";
import {useNavigate} from "react-router-dom"


const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("")
  const [newPassword, setNewPassword] = useState("")

  const navigate = useNavigate()
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:4000/api/auth/forgotPassword",
        { email, otp, newPassword }
      );
      if (response.data.success) {
        navigate("/login")
        console.log(response.data)
      }
      // Show success message
    } catch (error) {
      console.error(error);
      // Show error message
    }
  };

  return (
    <>
      <div className="forgot-password-popup">
        <form className="forgot-password-form" onSubmit={handleSubmit}>
          <h2 className="fw-bold">Forgot Password</h2>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
          />
           <input
            type="text"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            placeholder="OTP"
          />
           <input
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="New Password"
          />
          <div className="form-links">
            <Link to="/Signup">Sign Up</Link>
            <Link to="/login">Login Page</Link>{" "}
          </div>
          <button className="cs-linear-tb fw-bold" type="submit">Reset Password</button>
        </form>
      </div>
    </>
  );
};

export default ForgotPassword;

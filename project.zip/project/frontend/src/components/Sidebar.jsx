import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faTachometerAlt,
  faBook,
  faPuzzlePiece,
  faTasks,
  faUserCircle,
  faCog,
  faSignOutAlt,
} from "@fortawesome/free-solid-svg-icons";

function Sidebar() {
  return (
    <aside className="bg-gray-100 w-64 p-4 h-full overflow-y-auto">
      <ul>
        <li className="sidebar-item">
          <FontAwesomeIcon icon={faTachometerAlt} className="icon" />
          <a href="/dashboard">Dashboard</a>
        </li>
        <li className="sidebar-item">
          <FontAwesomeIcon icon={faBook} className="icon" />
          <a href="/courses">Courses</a>
        </li>
        <li className="sidebar-item">
          <FontAwesomeIcon icon={faPuzzlePiece} className="icon" />
          <a href="/quizzes">Quizzes</a>
        </li>
        <li className="sidebar-item">
          <FontAwesomeIcon icon={faTasks} className="icon" />
          <a href="/assignments">Assignments</a>
        </li>
        <li className="sidebar-item">
          <FontAwesomeIcon icon={faUserCircle} className="icon" />
          <a href="/profile">Profile</a>
        </li>
        <li className="sidebar-item">
          <FontAwesomeIcon icon={faCog} className="icon" />
          <a href="/settings">Settings</a>
        </li>
        <li className="sidebar-item">
          <FontAwesomeIcon icon={faSignOutAlt} className="icon" />
          <a href="/logout">Logout</a>
        </li>
      </ul>
    </aside>
  );
}

export default Sidebar;

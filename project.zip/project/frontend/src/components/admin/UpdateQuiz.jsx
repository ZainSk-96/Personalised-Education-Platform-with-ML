import {useState, useEffect} from 'react'
import {useParams} from 'react-router-dom'
import axios from 'axios'
import QuizForm from './QuizForm'
const UpdateQuiz = () => {
  const params = useParams()
  const [course, setCourse] = useState([])
  const [quizID, setQuizID] = useState('')
  const [quizData, setQuizData] = useState({
    number: '',
    question: '',
    optionOne: '',
    optionTwo: '',
    optionThree: '',
    optionFour: '',
    answer: ''
  })


  const getCourse = async () => {
    try {
      const {data} = await axios.get(`http://localhost:4000/api/course/get-quiz-for-update/${params.id}`)
      if (!data.success) {
        console.log(data?.error, data?.message)
      } else {
        setCourse(data?.course)
      }
      
    } catch (error) {
      console.log(error, error.data.message, error.data.error)
    }
    
  }

  useEffect(() => {
    getCourse()
  }, [])


const initializeQuizzes = async() => {
  try {
    const {data} = await axios.post(`http://localhost:4000/api/course/initialize-quizzes/${course?._id}`)

    if (data?.success) {
      console.log("Quiz Created Successfully")
      getCourse()
    }
  } catch (error) {
    console.log(error, error.data.error, error.data.message)
  } 
}  

const quizValueHandler = (e) => {
  setQuizData({
    ...quizData,
    [e.target.name]: e.target.value
  })
}

 const quizSubmitHandler = async (e, courseID,qID) => {
  e.preventDefault()
  try {
    const response = await axios.post(`http://localhost:4000/api/course/create-quiz-question/${params.id}`,
      {
        courseID,
        quizID: qID,
        number: quizData.number, 
        question: quizData.question, 
        optionOne: quizData.optionOne, 
        optionTwo: quizData.optionTwo, 
        optionThree: quizData.optionThree, 
        optionFour: quizData.optionFour, 
        answer: quizData.answer
      }
    )

    if (response?.data?.success === false) {
      return console.log('Submit Failed: Res: ', response?.data?.message, response?.data?.error)
    }

    getCourse()
  } catch (error) {
    console.log(error)
  }
 }

 const deleteQuestionHandler = async (questionID, courseID, qID) => {
  try {
    console.log('Params:', params); // Check if params contains the expected values
    console.log('Course ID:', params.id); //
    const {data} = await axios.post(`http://localhost:4000/api/course/delete-quiz-question/${params.id}`,
    {
      questionID,
      courseID,
      quizID: qID
    }
    )

    if (data?.success) {
      console.log("Question Delete Successfully")
      getCourse()
    } else (
      console.log("Error Encountered In Deleting Quiz Question", error)
    )
  } catch (error) {
    
  }
 }
  return (
    <div className="container-fluid cs-height-def cs-bg-exlight">


      <div className="row p-3 m-3">
        
        <div className="col-md-3 w30 list-group list-group-flush bg-white rounded p-3">
          <h1>Quiz List</h1>

          <button onClick={() => setQuizID('Mid')} className='list-group-item'>
           Mid Quiz
          </button>
          <button onClick={() => setQuizID('Final')} className='list-group-item'>
            Final Quiz
          </button>
        </div>
        <div className="col-md-9 w65 flex flex-col">
          {!course?.quiz1 ? (
            <>
          <h1 className='border-primary border-2 p-2 fs-5'>Click Below to Initialize Quizzes</h1>
          <button onClick={initializeQuizzes} className='border-primary border-2 p-2 fs-5'>Click Below to Initialize Quizzes</button>
          </>
          ) : null}
        <h1 className='fs-4 pt-2 fw-bold tex'>Quiz # {quizID} Add Question</h1>
          
          <div className="w80 mt-2 mb-5 p-3 border rounded border shadow cs-margin-auto bg-white" style={{maxWidth:"1000px"}}>
          <p className="bg-danger text-white p1 fs-5"># {!quizID ? 'Select Quiz First!': `# ${quizID} Quiz!!!`} </p>
          <form onSubmit={(e) => quizSubmitHandler(e, course?._id,quizID)} className="pt-3 pb-3 flex flex-col align-middle">
            <input onChange={(e) => quizValueHandler(e)} value={quizData.number} name="number" className="form-control mb-3" type="text" placeholder="Question No."/>
            <input onChange={(e) => quizValueHandler(e)} value={quizData.question} name="question" className="form-control mb-3" type="text" placeholder="Question"/>
            <input onChange={(e) => quizValueHandler(e)} value={quizData.optionOne} name="optionOne" className="form-control mb-3" type="text" placeholder="Option 1"/>
            <input onChange={(e) => quizValueHandler(e)} value={quizData.optionTwo} name="optionTwo" className="form-control mb-3" type="text" placeholder="Option 2"/>        
            <input onChange={(e) => quizValueHandler(e)} value={quizData.optionThree} name="optionThree" className="form-control mb-3" type="text" placeholder="Option 3"/>
            <input onChange={(e) => quizValueHandler(e)} value={quizData.optionFour} name="optionFour" className="form-control mb-3" type="text" placeholder="Option 4"/>
            <label className="text-danger border-top pt-1 mb-3 border-danger"> Submit Right Answer: Please Write Exact value as provided in Option </label>         
           <input onChange={(e) => quizValueHandler(e)} value={quizData.answer} name="answer" className="form-control border-danger mb-3" type="text" placeholder="Option 4"/>
            <button className="btn btn-primary cs-bg-primary border-none w50 cs-margin-auto rounded-pill"type="submit">Create Quiz</button>
          </form>
          </div>

          <div className='rounded bg-white'>
          <h1 className='fs-5 pt-2 fw-bold tex'>Quiz # {quizID} Data</h1>

          <table className="table">
                  <thead>
                    <tr>
                      <th scope="col">Question</th>
                      <th scope="col">Option 1</th>
                      <th scope="col">Option 2</th>
                      <th scope="col">Option 3</th>
                      <th scope="col">Option 4</th>
                      <th scope="col">Delete Question</th>
                      
                    </tr>
                  </thead>
            <tbody>
            {quizID === 'Mid' ? (<>
              {course?.quiz1?.map((element) => {
                return (
                  <>
                <tr key={element?._id} className="align-middle">
                <td className='scrollable-td'>{element?.question}</td>
                <td>{element?.optionOne}</td>
                <td>{element?.optionTwo}</td>
                <td>{element?.optionThree}</td>
                <td>{element?.optionFour}</td>
                <td>
                  <button className="btn btn-secondary cs-bg-dark cs-border-none ml-1 rounded-pill"
                    onClick = {() => deleteQuestionHandler(element?._id, course?._id, quizID)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
                  </>
                )
              })}
            </>) : quizID === 'Final' ? (<>
              {course?.quiz2?.map((element) => {
                return (
                  <>
                  <tr key={element?._id} className="align-middle">
                  <td className='scrollable-td'>{element?.question}</td>
                  <td>{element?.optionOne}</td>
                  <td>{element?.optionTwo}</td>
                  <td>{element?.optionThree}</td>
                  <td>{element?.optionFour}</td>
                  <td>
                    <button className="btn btn-secondary cs-bg-dark cs-border-none ml-1 rounded-pill"
                      onClick = {() => deleteQuestionHandler(element?._id, course?._id, quizID)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
                  </>
                )
              })}
            </>) : (null)}
            </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>
  )
}

export default UpdateQuiz
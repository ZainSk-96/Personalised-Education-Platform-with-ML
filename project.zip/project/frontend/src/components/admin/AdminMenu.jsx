import {NavLink} from 'react-router-dom'
const AdminMenu = () => {
  return (
  <>
  <div className='shadow'>
    <NavLink to="/dashboard/admin/create-category" className="list-group-item list-group-item-action py-3" aria-current="true">
      Create Category
    </NavLink>
    <NavLink to="/dashboard/admin/create-course" className="list-group-item list-group-item-action py-3">
      Create/Update Course
    </NavLink>
    <NavLink to="/dashboard/admin/create-skill" className="list-group-item list-group-item-action py-3">
      Create/Update Skill
    </NavLink>
    <NavLink to="/dashboard/user/profile" className="list-group-item list-group-item-action py-3">
      User's Dashboard
    </NavLink>
  </div>
  </>
  )
}

export default AdminMenu
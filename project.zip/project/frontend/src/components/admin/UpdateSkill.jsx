import {useState, useEffect} from 'react'
import {useParams} from 'react-router-dom'
import axios from 'axios'
import AdminMenu from './AdminMenu'
const UpdateQuiz = () => {
  const params = useParams()
  const [skill, setSkill] = useState()
  const [quizData, setQuizData] = useState({
    number: '',
    question: '',
    optionOne: '',
    optionTwo: '',
    optionThree: '',
    optionFour: '',
    answer: ''
  })
  
  console.log(params)
const getSkill = async () => {
  try {
    const {data} = await axios.get(`http://localhost:4000/api/ml/get-skill/${params.id}`)

    if (data?.success) {
      setSkill(data?.skill)
    } else {
      console.log('Error Fetching Skill: ', data?.message, data?.error)
    }
  } catch (error) {
    console.log('Error from Server in Fetching Skill: ', error)
  }
}

useEffect(() => {
  if(params?.id) {
    getSkill()
  }
}, [params?.id])

const quizValueHandler = (e) => {
  setQuizData({
    ...quizData,
    [e.target.name]: e.target.value
  })
}

 const quizSubmitHandler = async (e, qID) => {
  e.preventDefault()
  try {
    const response = await axios.post(`http://localhost:4000/api/ml/create-skill-quiz-question/${params.id}`,
      {
        skillID: params.id,
        quizID: qID,
        number: quizData.number, 
        question: quizData.question, 
        optionOne: quizData.optionOne, 
        optionTwo: quizData.optionTwo, 
        optionThree: quizData.optionThree, 
        optionFour: quizData.optionFour, 
        answer: quizData.answer
      }
    )

    if (response?.data?.success === false) {
      return console.log('Submit Failed: Res: ', response?.data?.message, response?.data?.error)
    }

    getSkill()
  } catch (error) {
    console.log(error)
  }
 }

 const deleteQuestionHandler = async (questionID, qID) => {
  try {
    console.log('Params:', params); // Check if params contains the expected values
    console.log('Skill ID:', params.id); //
    const {data} = await axios.post(`http://localhost:4000/api/ml/delete-quiz-question/${params.id}`,
    {
      questionID,
      skillID: qID
    }
    )

    if (data?.success) {
      console.log("Question Delete Successfully")
      getCourse()
    } else (
      console.log("Error Encountered In Deleting Quiz Question", error)
    )
  } catch (error) {
    console.log(error)
  }
 }

 useEffect(() => {
  console.log(skill)

 }, [])
  return (
    <div className="container-fluid cs-height-def cs-bg-exlight">


      <div className="row p-3 m-3">
        
        <div className="col-md-3 w30 list-group list-group-flush bg-white rounded p-3">
          <AdminMenu />
        </div>
        <div className="col-md-9 w65 flex flex-col">

        <h1 className='fs-4 pt-2 fw-bold tex'>Quiz For {skill?.name}: Add Question</h1>
          
          <div className="w80 mt-2 mb-5 p-3 border rounded border shadow cs-margin-auto bg-white" style={{maxWidth:"1000px"}}>
          <form onSubmit={(e) => quizSubmitHandler(e, skill?._id)} className="pt-3 pb-3 flex flex-col align-middle">
            <input onChange={(e) => quizValueHandler(e)} value={quizData.number} name="number" className="form-control mb-3" type="text" placeholder="Question No."/>
            <input onChange={(e) => quizValueHandler(e)} value={quizData.question} name="question" className="form-control mb-3" type="text" placeholder="Question"/>
            <input onChange={(e) => quizValueHandler(e)} value={quizData.optionOne} name="optionOne" className="form-control mb-3" type="text" placeholder="Option 1"/>
            <input onChange={(e) => quizValueHandler(e)} value={quizData.optionTwo} name="optionTwo" className="form-control mb-3" type="text" placeholder="Option 2"/>        
            <input onChange={(e) => quizValueHandler(e)} value={quizData.optionThree} name="optionThree" className="form-control mb-3" type="text" placeholder="Option 3"/>
            <input onChange={(e) => quizValueHandler(e)} value={quizData.optionFour} name="optionFour" className="form-control mb-3" type="text" placeholder="Option 4"/>
            <label className="text-danger border-top pt-1 mb-3 border-danger"> Submit Right Answer: Please Write Exact value as provided in Option </label>         
           <input onChange={(e) => quizValueHandler(e)} value={quizData.answer} name="answer" className="form-control border-danger mb-3" type="text" placeholder="Option 4"/>
            <button className="btn btn-primary cs-bg-primary border-none w50 cs-margin-auto rounded-pill" type="submit">Create Quiz</button>
          </form>
          </div>

          <div className='rounded bg-white'>
          <h1 className='fs-5 pt-2 fw-bold tex'>Quiz Data</h1>

          <table className="table">
                  <thead>
                    <tr>
                      <th scope="col">Question</th>
                      <th scope="col">Option 1</th>
                      <th scope="col">Option 2</th>
                      <th scope="col">Option 3</th>
                      <th scope="col">Option 4</th>
                      <th scope="col">Delete Question</th>
                      
                    </tr>
                  </thead>
            <tbody>
            {skill?.quiz ? (<>
              {skill?.quiz?.map((element) => {
                return (
                  <>
                <tr key={element?._id} className="align-middle">
                <td className='scrollable-td'>{element?.question}</td>
                <td>{element?.optionOne}</td>
                <td>{element?.optionTwo}</td>
                <td>{element?.optionThree}</td>
                <td>{element?.optionFour}</td>
                <td>
                  <button className="btn btn-secondary cs-bg-dark cs-border-none ml-1 rounded-pill"
                    onClick = {() => deleteQuestionHandler(element?._id, skill._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
                  </>
                )
              })}
            </>): null}
            </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>
  )
}

export default UpdateQuiz
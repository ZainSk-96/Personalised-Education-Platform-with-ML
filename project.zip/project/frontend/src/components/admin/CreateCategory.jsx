import { useEffect, useState } from "react";
import axios from "axios";

import AdminMenu from "./AdminMenu";

const CreateCategory = () => {
  const [categories, setCategories] = useState([]);
  const [category, setCategory] = useState("");
  const [name, setName] = useState("");

  const getAllCategories = async () => {
    try {
      const response = await axios.get(
        "http://localhost:4000/api/category/categories"
      );
      if (response.data.success) {
        setCategories(response.data.categories);
      }
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    getAllCategories();
  }, []);
  // Handlers
  const changeHandler = (e) => {
    setName(e.target.value);
  };

  const submitHandler = async (e) => {
    try {
      e.preventDefault();
      const response = await axios.post(
        "http://localhost:4000/api/category/create-category/",
        { name }
      );
      if (!response.data.success) {
        console.log("Request Failed, Response: ", response.data.message);
      } else {
        console.log("Category Created Successfully");
        getAllCategories();
      }
    } catch (error) {
      console.log(error);
    }
  };

  const deleteHandler = async (_id) => {
    try {
      const response = await axios.post(
        `http://localhost:4000/api/category/delete-category/${_id}`,
        {
          _id,
        }
      );
      console.log(_id);
      getAllCategories();
    } catch (error) {
      console.log(error, _id);
    }
  };
  return (
    <>
      <div className="container-fluid cs-height-def cs-bg-exlight">
        <div className="row p-3">
        <div className="col-md-3 list-group list-group-flush w35">

            <AdminMenu />
          </div>
          <div className="col-md-9 w65">
          <div className="w80 mb-5 p-3 border rounded border shadow cs-margin-auto bg-white" style={{maxWidth:"1000px"}}>

              <form onSubmit={submitHandler} className="text-start">
                <span className="mb-3">Create New Category</span>
                <input
                  className="form-control rounded mb-3 border-dark"
                  type="text"
                  value={name}
                  onChange={changeHandler}
                />
                <button
                  type="submit"
                  className="btn btn-primary cs-bg-primary "
                >
                  Create
                </button>
              </form>
            </div>
            <div className="fs-2"> Manage Categories </div>
            <table className="table border shadow">
              <thead>
                <tr className="text-start">
                  <th scope="col">Name</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody className="table-group-divider">
                {categories.map((element) => {
                  return (
                    <>
                      <tr className="text-start">
                        <td key={element._id}>{element.name}</td>
                        <td>
                          <button
                            class="btn btn-primary cs-bg-primary"
                            onClick={() => deleteHandler(element._id)}
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    </>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
};

export default CreateCategory;

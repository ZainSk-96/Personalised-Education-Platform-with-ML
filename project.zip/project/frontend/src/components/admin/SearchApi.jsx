import { useEffect, useState } from "react";
import axios from "axios";

const SearchApi = (props) => {
  const { url, dataObject, placeholder, onRecieveRes, fetchDataReq } = props;
  const [search, setSearch] = useState([]);
  const [sValue, setSValue] = useState([]);
  const [category, setCategory] = useState({});
  const [categories, setCategories] = useState([]);
  const [optionValue, setOptionValue] = useState('');

  
  const getItems = async () => {
    try {
      const response = await axios.get(url, fetchDataReq?fetchDataReq:null);
      if (response.data.success) {
        setCategories(response.data[dataObject]);
        console.log(response.data[dataObject])
      }
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    // fetchData = async()
    getItems();
  }, []);

  const initialItems = categories;

  const selectHandler = (selectedValue) => {
    const selectedObject = JSON.parse(selectedValue)
    setCategory(selectedObject);
  };
  const handleSearch = (e, sValue) => {
    setSValue(e.target.value);
    const searchArray = categories.filter((word) =>
      word.name.startsWith(sValue)
    );
    setSearch(searchArray);
  };


  useEffect(() => {
    if (category !== null) {
      onRecieveRes(category);
    }
  }, [category, onRecieveRes]);

  return (
    <>
      <input
        className="form-control mb-3"
        type="search"
        value={sValue}
        placeholder={sValue}
        onChange={(e) => {
          handleSearch(e, sValue);
        }}
      />
      <select
        className="form-select form-select-sm"
        onChange={(event) => selectHandler(event.target.value)}
      >
        {!sValue
          ? initialItems.map((result) => {
              return (
                <option key={result._id} value={JSON.stringify(result)}>
                  {result.name}
                </option>
              );
            })
          : search.map((result) => {
              return (
                <option key={result._id} value={JSON.stringify(result)}>
                  {result.name}
                </option>
              );
            })}
      </select>
    </>
  );
};

export default SearchApi;

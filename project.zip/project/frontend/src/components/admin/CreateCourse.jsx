import { useEffect, useState } from "react";
import axios from "axios";
import AdminMenu from "./AdminMenu";
import SearchApi from "./SearchApi";
import {useNavigate} from 'react-router-dom'

const CreateCourse = () => {
  const navigate = useNavigate()
  const [categories, setCategories] = useState([]);
  const [category, setCategory] = useState(null);
  const [data, setData] = useState()
  const [image, setImage] = useState("");
  const [fData, setFData] = useState({
    name: "",
    description: "",
    instructor: "",
  });
  const [courses, setCourses] = useState([])
  const categoriesURL = "http://localhost:4000/api/category/categories";
  const coursesURL = "http://localhost:4000/api/course/all-courses";

  const requiredData = {
    reqData: "name instructor"
  }
  const getAllCourses = async () => {
    try {
      const response = await axios.get(coursesURL, {
        params: requiredData
      })
      const {data} = response
      if (!response) {
       return console.log(data.message, data.error)
      }
      setCourses(data?.courses)
    } catch (error) {
      console.log(error)
    }
  }

  useEffect(() => {
    getAllCourses()
  
  }, [])

  const handleCourseForm = (e) => {
    setFData({
      ...fData,
      [e.target.name]: e.target.value,
    });
    
  };
  const handleResponse = (category) => {
    setCategory(category);
  };

  const handleData = (data) => {
    setData(data);
  }

  useEffect(() => {
    console.log(category)
  }, [category])

  const formData = new FormData()
    formData.append("name", fData.name);
    formData.append("description", fData.description);
    formData.append("instructor", fData.instructor);
    formData.append("category", category?._id);
    formData.append("image", image);

const handletestRes = () => {

}

  const handleCourseCreate = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:4000/api/course/create-course",
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data"
            }
          }
      );

      const { data } = response;
      if (data.success) {
        getAllCourses()

        console.log("Success", data.message);
      } else if (!data.success) {
        console.log(data.message, data.error);
      }
    } catch (e) {
    }
  };
  //Handle Course Delete
  const deleteURL = "http://localhost:4000/api/course/delete-course"

     
    const deleteHandler = async (_id) => {
      try {
        const response = await axios.post(
          `http://localhost:4000/api/course/delete-course/${_id}`,
          {
            _id,
          }
        );
        console.log(_id);
        getAllCourses()
      } catch (error) {
        console.log(error, error.message, _id);
      }
    };
     // const response = await axios.post(url, _id)


  // Getting All Categories
  return (
    <>
      <div className="container-fluid cs-height-def cs-bg-eexlight">
        <div className="row p-3 justify-content-space-between">
          <div className="col-md-3 list-group list-group-flush w35">
            <AdminMenu />
          </div>
          <div className="col-md-9 flex flex-col w65">
            {/** Course Creation form Form */}
            <div className="w80 mb-5 p-3 border rounded-4 border shadow cs-margin-auto bg-white" style={{maxWidth:"1000px"}}>
              <h3 className="fs-3"> Create Course </h3>

              <form
                className="pt-3 pb-3 flex flex-col align-middle"
                onSubmit={handleCourseCreate}
                enctype="multipart/form-data"
              >
                <input
                  className="form-control mb-3"
                  type="text"
                  name="name"
                  value={fData.name}
                  onChange={handleCourseForm}
                  placeholder="Course Name"
                />
                <textarea
                  className="form-control mb-3"
                  type="text"
                  name="description"
                  value={fData.description}
                  onChange={handleCourseForm}
                  placeholder="Course Description"
                  Style="height: 100px"
                ></textarea>
                <input
                  className="form-control mb-3"
                  type="text"
                  name="instructor"
                  value={fData.instructor}
                  onChange={handleCourseForm}
                  placeholder="Instructor Name"
                />

                <SearchApi
                  url={categoriesURL}
                  dataObject="categories"
                  placeholder="Search Category"
                  onRecieveRes={handleResponse}
                />

                <p className='cs-fs-18 fw-bold'>Selected Category: {category?.name ? category.name : 'No Category Selected'}</p>

                <label className="border border-dark mt-3">
                  Selected Image: {image ? image.name : "No Image Selected"}{" "}
                </label>
                <label className="btn btn-primary cs-bg-primary mt-3" style={{maxWidth:"200px"}}>
                  {"Upload Image"}
                  <input
                    name="image"
                    type="file"
                    accept="image/*"
                    onChange={(e) => setImage(e.target.files[0])}
                    hidden
                  />
                </label>
                <div className="mt-3">
                  {image && (
                    <img
                      src={URL.createObjectURL(image)}
                      className="img img-responsive"
                      Style="height: 100px"
                    />
                  )}
                </div>

                <button
                  className="btn btn-primary cs-bg-primary rounded-pill w-100 cs-margin-auto mt-3"
                  type="submit"
                  style={{maxWidth:"250px"}}
                >
                  Confirm!
                </button>
              </form>
            </div>

            {/** Course Creation form Form 

            <form onSubmit={handle}>
              <input
                className="form-control"
                type="text"
                name="name"
                value={fData.name}
                onChange={handleCourseForm}
              />
              <button type="submit">Submit</button>
            </form>*/}
            <div className="" style={{maxWidth: '1000px'}}> 

            <h2 className="fs-2 mb-3">Manage Courses</h2>
            <div className="rounded-4 shadow bg-white p-3">
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Course Name</th>
                  <th scope="col">Instructor Name</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                { courses.map((element) => {
                  return (
                    <>
                    <tr key={element._id} className="align-middle">
                  <td>{element.name}</td>
                  <td>{element.instructor}</td>
                  <td>
                    <button
                      type="button"
                      className="btn btn-primary cs-bg-aquablue mr-2 cs-border-none rounded-pill text-light"
                      onClick={() => navigate(`/dashboard/admin/update-course/${element._id}`)}
                    >
                      Update Lectures
                    </button>
                    <button
                      type="button"
                      className="btn btn-primary cs-bg-primary cs-border-none rounded-pill text-light"
                      onClick={() => navigate(`/dashboard/admin/update-quiz/${element._id}`)}
                    >
                      Update Quizzes
                    </button>
                    <button className="btn btn-secondary cs-bg-dark cs-border-none ml-2 rounded-pill"
                      onClick = {() => deleteHandler(element._id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
                    </>
                  )
                })
                 }
                             
              </tbody>
            </table>
            </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CreateCourse;

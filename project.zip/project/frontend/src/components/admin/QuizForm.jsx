import React from 'react'

const QuizForm = (props) => {
  const {quizID} = props
  return (
    <>
    <form onSubmit={(e) => quizHandler(e, course?._id)} className="pt-3 pb-3 flex flex-col align-middle">
      <input onChange={quizSetter} value={quizData.question} name="question" className="form-control mb-3" type="text" placeholder="Quiz Question"/>
      <input onChange={quizSetter} value={quizData.optionOne} name="optionOne" className="form-control mb-3" type="text" placeholder="Option 1"/>
      <input onChange={quizSetter} value={quizData.optionTwo} name="optionTwo" className="form-control mb-3" type="text" placeholder="Option 2"/>        <input onChange={quizSetter} value={quizData.optionThree} name="optionThree" className="form-control mb-3" type="text" placeholder="Option 3"/>
      <input onChange={quizSetter} value={quizData.optionFour} name="optionFour" className="form-control mb-3" type="text" placeholder="Option 4"/>
      <label className="text-danger border-top pt-1 mb-3 border-danger"> Submit Right Answer: Please Write Exact value as provided in Option </label>          <input onChange={quizSetter} value={quizData.answer} name="answer" className="form-control border-danger mb-3" type="text" placeholder="Option 4"/>
      <button className="btn btn-primary cs-bg-primary border-none w50 cs-margin-auto rounded-pill"type="submit">Create Quiz</button>
    </form>
    </>
  )
}

export default QuizForm
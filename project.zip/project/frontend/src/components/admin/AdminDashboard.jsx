
import AdminMenu from './AdminMenu.jsx'
import {useState, useEffect} from 'react'
import axios from 'axios'


const AdminDashboard = () => {
  const [user, setUser] = useState()
  const getUser = async () => {
    try {
    const {data} = await axios.get('http://localhost:4000/api/auth/get-user')
    if (data?.success) {
      setUser(data?.user)
    } else {
      console.log("Something Went Wrong in getting User Details", data?.message, data?.error)
    }
  } catch (error) {
    console.log(error)
  }
  }

useEffect(()=> {
  getUser()
},[])

  return (
  <>
    <div className="container-fluid cs-height-def">
      <div className="row p-3 cs-bg-eexlight" style={{height: '100vh'}}>
        <div className="col-md-3 list-group list-group-flush w35 rounded px-6">
          <AdminMenu />
        </div>
        <div className="col-md-9 w65">
        <div className="border border-dark p-3 rounded">
            <h1 className="fs-3 border-bottom mb-3"> Welcome Back! </h1>
            <h4 className="fs-5 mb-3">Name: {user?.name}</h4>
            <h4 className="fs-5 mb-3">Email: {user?.email}</h4>
          </div>
        </div>
      </div>
    </div>
  </>
)

}

export default AdminDashboard
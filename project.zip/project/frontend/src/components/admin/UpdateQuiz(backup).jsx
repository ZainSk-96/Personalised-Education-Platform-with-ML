import {useEffect, useState} from 'react'
import axios from 'axios'
import {useParams} from 'react-router-dom'
import CourseSidePanel from '../courses/CourseSidePanel'
import AdminMenu from "./AdminMenu";


const UpdateQuiz = () => {
  const [course, setCourse] = useState({})
  const [quizzes, setQuizzes] = useState([])
  const [quizID, setQuizID] = useState('')
  const params = useParams()

  const [quizData, setQuizData] = useState({
    number: '',
    question: '',
    optionOne: '',
    optionTwo: '',
    optionThree: '',
    optionFour: '',
    answer: ''
  })
  const [quizNumber, setQuizNumber] = useState(0) // For Adding Quiz
  const getQuiz = async() => {
    try {
      const {data} = await axios.get(`http://localhost:4000/api/course/get-quiz-for-update/${params.id}`)

      setCourse(data?.course)
      setQuizzes(data?.quizzes)
    } catch (error) {
      
    }
}

useEffect(() => {
  if(params?.id) {
    getQuiz()
  }
}, []) 

// For Creating Initial Quiz

const quizValueHandler = (e) => {
  setQuizNumber(e.target.value)
}

const addQuiz = async (e, _id) => {
  e.preventDefault()
  try {
    const response = await axios.post(`http://localhost:4000/api/course/add-quiz/${_id}`,
    {
      courseID: _id,
      number: quizNumber
    })
    console.log(response)
  } catch (error) {
    
  }
}
// For Creating Inital Quiz END //////

// For Setting Quiz ID in Question Form

const quizFormSetter = (id) => {
  setQuizID(id)
}

// --------------End-------------------

const quizSetter = (e) => {
  setQuizData(
    {
      ...quizData,
      [e.target.name]: e.target.value
    }
  )
}

const quizHandler = async (e, _id, quizID) => {
  e.preventDefault()
  try {
    const response = await axios.post(`http://localhost:4000/api/course/create-quiz-question/${_id}`,
      {
        courseID: _id,
        quizID: quizID,
        number: quizData.number, 
        question: quizData.question, 
        optionOne: quizData.optionOne, 
        optionTwo: quizData.optionTwo, 
        optionThree: quizData.optionThree, 
        optionFour: quizData.optionFour, 
        answer: quizData.answer
      }
    )

    if (response?.data?.success === false) {
      return console.log('Submit Failed: Res: ', response?.data?.message, response?.data?.error)
    }

    console.log( "Res: ", response?.data?.message)
  } catch (error) {
    console.log(error)
  }
  }

  return (
    <div className="container-fluid cs-height-def cs-bg-exlight">
      <div className="row p-3 m-3">
        <div className="col-md-3 w30 list-group list-group-flush bg-white rounded p-3">
        <h1>Quiz List</h1>
          {quizzes?.map((element) => {
            return(
              <>
              <button onClick={() => quizFormSetter(element._id)} key={element._id}>Quiz No. # {element.qnumber}</button>
              </>
            )
          })}

        </div>
        <div className="col-md-9 w65 flex flex-col">
        <h3 className="fs-3"> Add New Quiz </h3>
        <h2 className='text-danger fs-5'>For : {course?.name}</h2>
        <form onSubmit={(e) => addQuiz(e, course?._id)} >
          <input onChange={quizValueHandler} value={quizNumber} className='form-control border-primary border-4 mb-3' placeholder='Quiz Number' type="number" name="quiznumber" />
          <button type="submit" className='btn btn-primary border-none rounded-pill'>Add Quiz</button>

        </form>
          {JSON.stringify(course,4,null)}
          
        <div className="w80 mt-5 mb-5 p-3 border rounded border shadow cs-margin-auto bg-white" style={{maxWidth:"1000px"}}>

        <h3 className="fs-3"> Create Question For: </h3>
            <h1 className='bg-danger text-white rounded p-1'>{quizID ? 'Selected Quiz ID#' : 'Warning: No Quiz Selected'}</h1>
            <h1>{quizID}</h1>
            <h2>{course?.name}</h2>
            <form onSubmit={(e) => quizHandler(e, course?._id, quizID)} className="pt-3 pb-3 flex flex-col align-middle"
              
            >
              <input onChange={quizSetter} value={quizData.number} name="number" className="form-control mb-3" type="number" placeholder="Quiz Number (unique)"/>
              <input onChange={quizSetter} value={quizData.question} name="question" className="form-control mb-3" type="text" placeholder="Quiz Question"/>
              <input onChange={quizSetter} value={quizData.optionOne} name="optionOne" className="form-control mb-3" type="text" placeholder="Option 1"/>
              <input onChange={quizSetter} value={quizData.optionTwo} name="optionTwo" className="form-control mb-3" type="text" placeholder="Option 2"/>
              <input onChange={quizSetter} value={quizData.optionThree} name="optionThree" className="form-control mb-3" type="text" placeholder="Option 3"/>
              <input onChange={quizSetter} value={quizData.optionFour} name="optionFour" className="form-control mb-3" type="text" placeholder="Option 4"/>
              <label className="text-danger border-top pt-1 mb-3 border-danger"> Submit Right Answer: Please Write Exact value as provided in Option </label>
              <input onChange={quizSetter} value={quizData.answer} name="answer" className="form-control border-danger mb-3" type="text" placeholder="Option 4"/>
              <button className="btn btn-primary cs-bg-primary border-none w50 cs-margin-auto rounded-pill"type="submit">Create Quiz</button>
          </form>
        </div>
        </div>
      </div>
    </div>
  )
}

export default UpdateQuiz
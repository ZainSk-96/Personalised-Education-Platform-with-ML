import { useEffect, useState } from "react";
import {useNavigate, useParams} from 'react-router-dom'
import axios from "axios";
import AdminMenu from "./AdminMenu";

const CreateSkill = () => {
  const params = useParams()
  const navigate = useNavigate()
  const [skills, setSkills] = useState([]);
  const [skill, setSkill] = useState("");
  const [name, setName] = useState("");
  const [beginnerValue, setBeginnerValue] = useState('');
  const [beginner, setBeginner] = useState([])
  const [intermediateValue, setIntermediateValue] = useState('');
  const [intermediate, setIntermediate] = useState([])
  const [advancedValue, setAdvancedValue] = useState('');
  const [advanced, setAdvanced] = useState([])

const getSkills = async () => {
    try {
      const response = await axios.get(
        "http://localhost:4000/api/ml/get-skills-names"
      );

      console.log(response)
      if (response?.data?.success) {
        setSkills(response?.data?.skills);
      }
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    getSkills();
  
  }, []);
  // Handlers
  const nameChangeHandler = (e) => {
    setName(e.target.value);
  };

  const beginnerValueChangeHandler = (e) => {
    setBeginnerValue(e.target.value);
  };

  const beginnerArrayChangeHandler = () => {
    setBeginner((prev) => [...prev, beginnerValue])
    setBeginnerValue('')
  };
  const deleteBeginnerArrayElement = (valueToRemove) => {
    setBeginner((prev) => prev.filter((element) => element !== valueToRemove))
  }

  const intermediateValueChangeHandler = (e) => {
    setIntermediateValue(e.target.value);
  };

  const intermediateArrayChangeHandler = () => {
    setIntermediate((prev) => [...prev, intermediateValue])
    setIntermediateValue('')
  };
  const deleteIntermediateArrayElement = (valueToRemove) => {
    setIntermediate((prev) => prev.filter((element) => element !== valueToRemove))
  }

  const advancedValueChangeHandler = (e) => {
    setAdvancedValue(e.target.value);
  };

  const advancedArrayChangeHandler = () => {
    setAdvanced((prev) => [...prev, advancedValue])
    setAdvancedValue('')
  };

  const deleteAdvancedArrayElement = (valueToRemove) => {
    setAdvanced((prev) => prev.filter((element) => element !== valueToRemove))
  }

const submitHandler = async (e) => {
    try {
      e.preventDefault();
      const response = await axios.post(
        "http://localhost:4000/api/ml/create-skill",
        { name, beginner, intermediate, advanced }
      );
      if (!response.data.success) {
        console.log("Request Failed, Response: ", response.data.message);
      } else {
        console.log("Category Created Successfully");
        //getAllCategories();
      }
    } catch (error) {
      console.log(error);
    }
  };

  const updateQuizHandler = ( ) => {

  }

  const deleteHandler = async (_id) => {
    try {
      const response = await axios.post(
        `http://localhost:4000/api/ml/delete-skill/${_id}`,
        {
          _id,
        }
      );
      console.log(_id);
      getSkills()
    } catch (error) {
      console.log(error, _id);
    }
  };



  console.log(skills)
  return (
    <>
      <div className="container-fluid cs-height-def cs-bg-exlight">
        <div className="row p-3">
        <div className="col-md-3 list-group list-group-flush w35">

            <AdminMenu />
          </div>
          <div className="col-md-9 w65">
          <div className="w80 mb-5 p-3 border rounded border shadow cs-margin-auto bg-white" style={{maxWidth:"1000px"}}>

              <form onSubmit={submitHandler} className="text-start"  style={{maxWidth: '750px' }}>
                <span className="mb-3">Create New Skill</span>
                <input
                  className="form-control rounded mb-3 border-dark"
                  type="text"
                  value={name}
                  onChange={nameChangeHandler}
                />
                 <p className='cs-fs-18 fw-bold'>Add beginner Pathway Array</p>
                <input
                  className="form-control rounded mb-3 border-dark"
                  type="text"
                  value={beginnerValue}
                  onChange={beginnerValueChangeHandler}
                  placeholder="Enter New Value"
                />
                <button
                  type="button"
                  className="block btn cs-linear-tb text-white px-4 "
                  onClick={beginnerArrayChangeHandler}
                >
                  Add
                </button>
                <div className='flex' style={{maxWidth: '750px', flexWrap: 'wrap'}}>
                {beginner.map(
                  (element) => {
                    return (<>
                    <div key={element} className='mr-1'>
                    <span  className="badge py-2 px-4 btn text-dark btn-info rounded-pill fw-bold cs-fs-14">
                      {element} 
                    </span>
                    <span onClick={() => {deleteBeginnerArrayElement(element)}} type="button" className='material-symbols-outlined cs-fs-16 fw-bold cs-valign-top iconweight-100'>cancel</span>
                    </div>
                    </>)

                  })}
                </div>
                <p className='cs-fs-18 fw-bold'>Add Intermediate Pathway Array</p>
                <input
                  className="form-control rounded mb-3 border-dark"
                  type="text"
                  value={intermediateValue}
                  onChange={intermediateValueChangeHandler}
                  placeholder="Enter New Value"
                />
                <button
                  type="button"
                  className="block btn cs-linear-tb text-white px-4 "
                  onClick={intermediateArrayChangeHandler}
                >
                  Add
                </button>
                <div className='flex' style={{maxWidth: '750px', flexWrap: 'wrap'}}>

                {intermediate.map(
                  (element) => {
                    return (<>
                    <div key={element} className='mr-1'>
                    <span  className="badge py-2 px-4 btn text-dark btn-info rounded-pill fw-bold cs-fs-14">
                      {element} 
                    </span>
                    <span onClick={() => {deleteIntermediateArrayElement(element)}} type="button" className='material-symbols-outlined cs-fs-16 fw-bold cs-valign-top iconweight-100'>cancel</span>
                    </div>
                    </>)

                  })}
                  </div>
                <p className='cs-fs-18 fw-bold'>Add Advanced Pathway Array</p>
                <input
                  className="form-control rounded mb-3 border-dark"
                  type="text"
                  value={advancedValue}
                  onChange={advancedValueChangeHandler}
                  placeholder="Enter New Value"
                />
                <button
                  type="button"
                  className="block btn cs-linear-tb text-white px-4 "
                  onClick={advancedArrayChangeHandler}
                >
                  Add
                </button>
                <div className='flex' style={{maxWidth: '750px', flexWrap: 'wrap'}}>

                {advanced.map(
                  (element) => {
                    return (<>
                    <div key={element} className='mr-1'>
                    <span  className="badge py-2 px-4 btn text-dark btn-info rounded-pill fw-bold cs-fs-14">
                      {element} 
                    </span>
                    <span onClick={() => {deleteAdvancedArrayElement(element)}} type="button" className='material-symbols-outlined cs-fs-16 fw-bold cs-valign-top iconweight-100'>cancel</span>
                    </div>
                    </>)

                  })}
                  </div>
                <button
                  type="submit"
                  className="btn btn-primary cs-bg-primary mt-3"
                  style={{width: '200px'}}
                >
                  Create
                </button>
              </form>
            </div>

            

            <div className="fs-2"> Manage Skills </div>
            <table className="table border shadow">
              <thead>
                <tr>
                  <th scope="col">Name</th>
                  <th scope="col">Update Quiz</th>
                  <th scope="col">Delete</th>
                </tr>
              </thead>
              <tbody className="table-group-divider">
                {skills?.map((element) => {
                  return (
                    <>
                      <tr className="">
                        <td key={element?._id}>{element?.name}</td>
                        <td>
                          <button
                            class="btn btn-primary cs-bg-primary"
                            onClick={() => navigate(`/dashboard/admin/update-skill/${element._id}`)}
                          >
                            Update Quiz
                          </button>
                        </td>
                        <td>
                          <button
                            class="btn btn-primary cs-bg-primary"
                            onClick={() => deleteHandler(element?._id)}
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    </>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
};

export default CreateSkill;

import {useEffect, useState} from 'react'
import axios from 'axios'
import {useParams} from 'react-router-dom'
import CourseSidePanel from '../courses/CourseSidePanel'
const UpdateCourse = () => {

  const params = useParams()
  const [course, setCourse] = useState({})
  const [formData, setFormData] = useState({
    lecNum: '',
    video: '',
    arTitle: '',
    articleExp: ''
  })
  

  const getProduct = async() => {
      try {
        const {data} = await axios.get(`http://localhost:4000/api/course/get-course/${params.id}`)

        setCourse(data?.course)
      } catch (error) {
        
      }
  }

  useEffect(() => {
    if(params?.id) {
      getProduct()
    }
  }, []) 
 
  console.log(course) // Debug this later (Mulitple COnsole logs rerendes issue)

  ////////////////////////// Lecture Upload Controller ////////////////////////////
  const handleLectureFields = (e) => {
    setFormData( {
      ...formData,
      [e.target.name]: e.target.value
    }  
    )
  }
 
  const handleLectureSubmit = async (e, _id) => {
    e.preventDefault()
    try {
      const response = await axios.post(`http://localhost:4000/api/course/update-course/${_id}`,
        {_id, lecNum: formData.lecNum, video: formData.video, articleExp: formData.articleExp, arTitle: formData.arTitle}
      )

      if (response?.data?.success === false) {
        return console.log('Submit Failed: Res: ', response?.data?.message, response?.data?.error)
      }

      console.log( "Res: ", response?.data?.message)
    } catch (error) {
      console.log(error)
    }
  }





  ///////////////////////// Quiz Upload Controller ////////////////////////////////


  return (
    <>
    <div className="container-fluid cs-height-def cs-bg-exlight">
      <div className="row p-3 m-3">
      <div className="col-md-3 w30 list-group list-group-flush bg-white rounded p-3">
          <h1>Lecture List</h1>
          {course?.lecture?.map((element) => {
            return(
              <>
              <button key={element.number}>Lecture #{element.number}</button>
              </>
            )
          })}
      </div>
        <div className="col-md-9 w65 flex flex-col">
        <div className="mb-5 w90 p-3  border rounded border shadow cs-margin-auto bg-white" style={{maxWidth:"1000px"}}>
        <h3 className="fs-3"> Update Course </h3>
            <h1>{course?.name}</h1>
            <h2>{course?._id}</h2>
            <form onSubmit={(e) => handleLectureSubmit(e, course?._id)} className="p-4 flex flex-col align-middle">
              <input onChange={handleLectureFields} name="lecNum" value={formData.lecNum} className="form-control mb-3" type="number" placeholder="Lecture Number"/>
              <input onChange={handleLectureFields} name="video" value={formData.video} className="form-control mb-3" type="text" placeholder="video embeded link"/>
              <input onChange={handleLectureFields} name="arTitle" value={formData.arTitle} className="form-control mb-3" type="text" placeholder="Enter Title for Article"/>
              <textarea onChange={handleLectureFields} name="articleExp" value={formData.articleExp} className="form-control mb-3" placeholder="Enter Explanations of Article" style={{height: "200px"}}></textarea>
              <button type="submit" className="btn btn-primary cs-bg-primary rounded-pill w50 cs-margin-auto">Submit</button>
            </form>
        </div>

        

  
        </div>
      </div>
    </div>
    </>
  )
}

export default UpdateCourse
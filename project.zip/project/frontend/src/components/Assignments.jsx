import React from "react";
const Assignments = () => {
    return (
        <> 
        
            AssignMent Page
        </>
    )
}

export default Assignments
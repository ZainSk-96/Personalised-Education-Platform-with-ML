
import {useState, useEffect} from 'react'
import axios from 'axios'
import CourseCard from './courses/CourseCard.jsx'

const AllCourses = () => {
  const [courses, setCourses] = useState([])
  const coursesURL = "http://localhost:4000/api/course/all-courses";

  const requiredData = {
    reqData: "name instructor description category image"
  }
  const getAllCourses = async () => {
    try {
      const response = await axios.get(coursesURL, {
        params: requiredData
      })
      const {data} = response
      if (!response) {
       console.log(data.message, data.error)
      }
      setCourses(data?.courses)
    } catch (error) {
      console.log(error)
    }
  }

  useEffect(() => {
    getAllCourses()
  
  }, [])

  return (
    <div className="container-fluid p-5 row g-5 cs-x-center w100 ">
      {
        courses?.map((c) => {
          return (
          <div className="col-md-4">
            <CourseCard id={c?._id} description={c?.description} instructor={c?.instructor}
            category={c?.category}
            name={c?.name}
            image={c?.image?.data}
            />
          </div>
          )
        })
      }
    </div>
  )
}

export default AllCourses
import React, { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import {useAuth} from "./context/AuthContext.jsx"
import logo from "../assets/logo.png"
function Header() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [auth,setAuth] = useAuth()
  const navigate = useNavigate()
  const handleLogout = () => {
    setAuth({
      ...auth,
      user: null,
      token: ""
    })
    localStorage.removeItem("auth")
  }
  // Function to close the dropdown
  const closeDropdown = () => {
    setIsDropdownOpen(false);
  };


  return (
    <>
        <nav className="flex justify-between acenter align-middle cs-pt-6 cs-pb-6 cs-pl-40 cs-pr-40 border-bottom shadow-sm bg-white">
          <Link to="/" className="cs-navbar-item flex acenter">
            <img src ={logo} className="navbar-brand" style={{width: '60px'}}/>
            <p className="fw-bolder ml-2 fs-2 cs-mt-4">LMS</p>
          </Link>
          <div className="cs-navbar-item flex list-group flex flex-row list-group-flush ml-6">

          <NavLink to="/" className="list-group-item list-group-item-action border-none rounded-pill flex acenter cs-hover-primary" aria-current="true">
            <span className="material-symbols-outlined cs-valign">Home</span><p className="cs-mt-2">Home</p>
          </NavLink>
          <NavLink to="/courses" className="list-group-item flex flex-row acenter list-group-item-action rounded-pill border-none ml-2">
          <span className="material-symbols-outlined">local_library</span><p className="cs-mt-2">Courses</p>
          </NavLink>

          </div>
          
  
          <div className="list-group flex flex-row acenter align-middle list-group-flush">
     
    
            {!auth.user ? (
                    <>
                      <NavLink
                            to="/Signup"
                            className="text-white cs-bg-primary cs-linear-tb border-none rounded-pill align-middle px-4 py-2 fw-bold" 
                            onClick={closeDropdown}
                          >
                            SignUp
                      </NavLink>
                      <NavLink
                            to="/Login"
                            className="btn btn-secondary rounded-pill cs-bg-dark ml-1 px-4 py-2 border-none cs-lineard-tb"
                            onClick={closeDropdown, handleLogout}
                          >
                            Login
                      </NavLink>
              
                </>
            )  : (
              <> 
      
              
              <div className="dropdown">
            <Link className="btn btn-secondary dropdown-toggle cs-linear-tb border-none py-2 flex acenter" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <span className="material-symbols-outlined flex w100">manage_accounts</span><p className="">DropDown</p>
            </Link>

            <ul className="dropdown-menu text-center border shadow">
              <li><Link className="dropdown-item p-3 fw-bold cs-hover" to={`/dashboard/${auth?.user?.role === 1 ? 'admin' : 'user/profile'}`}> Dashboard </Link>
              </li>
              <li><Link onClick={handleLogout} className="dropdown-item p-3 cs-hover" to="/"> Logout </Link></li>
            </ul>
          </div>
              </>
            )
          }

          
          </div>
  
  
  
        </nav>
        </>
  );
}

export default Header;

import React, {useState, useEffect} from 'react'
import {Outlet} from "react-router-dom"
import axios from 'axios'
import {useAuth} from '../context/AuthContext'
import Spinner from '../reuse/Spinner'

const AdminPrivate = () => {
 const [adAccess, setAdAccess] = useState(false)
 const [auth, setAuth] = useAuth()

  useEffect(() => {
    const checkAuth = async () => {
      const res = await axios.get('http://localhost:4000/api/auth/admin-auth')
      if (res.data.adAccess) {
        setAdAccess(true)
      } else {
        setAdAccess(false)
      }
      
    }
    if (auth?.token) checkAuth()
  }, [auth?.token])

  return adAccess ? <Outlet/> : <Spinner /> 
}

export default AdminPrivate 
/*
import {useState, useEffect} from 'react'
import {useAuth} from '../context/AuthContext.jsx'
import {Outlet} from 'react-router-dom'
import axios from 'axios'
import Spinner from '../reuse/Spinner.jsx'

const AdminPrivate= () => {
    const [access, setAccess] = useState(false)
    const [auth, setAuth] = useAuth()

    useEffect(()=> {
       const checkAuth = async () => {
        const res = await axios.get('http://localhost:4000/api/auth/admin-auth')
        if (res.data.access) {
            setAccess(true)
        } else {
            setAccess(false)
        }
       }
       if (auth?.token) checkAuth()
    }, [auth?.token])
    return access ? <Outlet /> : <Spinner/>

}

export default AdminPrivate 
*/
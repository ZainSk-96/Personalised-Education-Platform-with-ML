import {useState, useEffect} from 'react'
import {useAuth} from '../context/AuthContext.jsx'
import {Outlet} from 'react-router-dom'
import axios from 'axios'
import Spinner from '../reuse/Spinner.jsx'

const PrivateRoute = () => {
    const [access, setAccess] = useState(false)
    const [auth, setAuth] = useAuth()

    useEffect(()=> {
       const checkAuth = async () => {
        const res = await axios.get('http://localhost:4000/api/auth/user-auth')
        if (res.data.access) {
            setAccess(true)
        } else {
            setAccess(false)
        }
       }
       if (auth?.token) checkAuth()
    }, [auth?.token])
    return access ? <Outlet /> : <Spinner/>

}

export default PrivateRoute 

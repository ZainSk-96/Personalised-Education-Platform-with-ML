import React, { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import Sidebar from "./Sidebar";
import {useNavigate} from "react-router-dom"

const Signup = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    otp: ""
  });
  const navigate = useNavigate() // For Redirecting to Login
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); // Page refresh default
    try {
      const response = await axios.post(
        "http://localhost:4000/api/auth/register",
        {name: formData.name, email: formData.email, password: formData.password, otp:formData.otp }
      );
      if(response.data.success) {
        navigate("/login")
        console.log(response.data);
      } else {
        console.log("ERROR in Response of REGISTER")
      }
      // Handle success (e.g., redirect, display message)
    } catch (error) {
      console.log(response.data);
      // Handle error (e.g., display error message)
    }
  };

  return (
    <>
      <div className="cs-height-def d-flex cs-bg-eexlight">
        <form className="signup-form signup-popup" onSubmit={handleSubmit}>
          <h2 className="fw-bold">Sign Up</h2>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Name"
          />
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Email"
          />
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="Password"
          />
          <input
            type="text"
            name="otp"
            value={formData.otp}
            onChange={handleChange}
            placeholder="OTP"
          />
          <div className="form-links">
            <Link to="/login">Log In</Link>
            <Link to="/Forgotpassword">Forgot Password?</Link>{" "}
          </div>
          <button className="cs-linear-tb fw-bold" type="submit">Sign Up</button>
        </form>
      </div>
    </>
  );
};

export default Signup;

import {useEffect, useState} from 'react'
import axios from 'axios'
import {useParams, Link} from 'react-router-dom'
import CourseCard from './CourseCard'

const CourseDetails = () => {

  const params = useParams()
  const [course, setCourse] = useState()
  const [enroll, setEnroll] = useState('Enroll Me')
  const [unEnroll, setUnEnroll] = useState('')

  useEffect(() => {
    if(params?.id) {
      getProduct()
    }
  }, [params?.id])
  console.log(params.id)
  const getProduct = async() => {
      try {
        const {data} = await axios.get(`http://localhost:4000/api/course/get-course-details/${params.id}`)

        setCourse(data?.course)
      } catch (error) {
        
      }
  }

  const enrollUser = async () => {
    try {
      const {data} = await axios.post(`http://localhost:4000/api/course/enroll-user/${params.id}`)
      
      if (data?.success) {
        setEnroll('Go To Course!')
      } else {
        console.log(data?.error, data?.message)
      }

    } catch (error) {
     console.log(error)
    }
  }
  
  const unEnrollUser = async () => {
    try {
      const {data} = await axios.post(`http://localhost:4000/api/course/unenroll-user/${params.id}`)
      
      if (data?.success) {
        console.log("user unenrolled successfully")
      } else {
        console.log(data?.error, data?.message)
      }

    } catch (error) {
     console.log(error)
    }
  }
    const image = course?.image?.data
  console.log(course?.description)
  return (
    <div className="container-fluid w100 align-start text-center" style={{maxWidth: '1200px'}}>
        <div className="container-fluid w100 border-bottom rounded-bottom-4 mb-4 border-dark shadow">
          <img src={`http://localhost:4000${image}`} className="object-fit-cover w100" style={{maxHeight: '300px'}} />

        </div>
        <div className="container-fluid w90 mb-5 p-5 border-start border-end">
        <Link to={`/dashboard/user/course/${course?._id}`}>

        <h1 className="fs-1 mb-2">{course?.name}</h1>
        <h1 className="fs-5 ">Course By  : {course?.instructor}</h1>

        <h1 className="fs-4 mb-2 text-start fw-bold">Course Description:</h1>

        <h1 className="fs-5 mb-2 text-start">{course?.description}</h1>

        </Link>
        <button className="p-3 text-white rounded mr-3 border-none cs-linear-tb" onClick={enrollUser}>{enroll}</button>
        <button className="btn border border-dark" onClick={unEnrollUser}>UnEnroll</button>
        </div>
    </div>
  )
}

export default CourseDetails
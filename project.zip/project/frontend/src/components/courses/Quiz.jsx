import {useEffect, useState} from 'react'
import {useNavigate} from 'react-router-dom'
import axios from 'axios'


const Quiz = (props) => {
  const navigate = useNavigate()
  const {quiz ,quizID ,url, uniqueID} = props
  const [answers, setAnswers] = useState(Array(10).fill(''))
  const [quizIndex, setQuizIndex] = useState(0)
  const [selectedOption, setSelectedOption] = useState('')
  const [complete, setComplete] = useState(false)


  const submitUrl = `${url}${uniqueID}` 

  console.log(submitUrl)

  const handleOptionSelect = (selectedOption) => {
    const updatedAnswers = [...answers]
    updatedAnswers[quizIndex] = selectedOption
    setAnswers(updatedAnswers)
  }

  const handleNextQuestion = () => {
    if (quizIndex < quiz.length -1) {
      setQuizIndex(quizIndex + 1)
    } 
    if (quizIndex === quiz.length -2) {
      setComplete(true)
    }
  }

  const handlePreviousQuestion = () => {
    if (quizIndex > 0) {
      setQuizIndex(quizIndex - 1)
    }
  }
  const handleSubmit = async () => {
    try {
      const {data} = await axios.post(submitUrl,
      {
        answers: answers,
        quizID: quizID
      }
      )
      if (data?.success) {
        console.log("Quiz Submitted Successfully")
        navigate('/dashboard/user/profile')
      }
    } catch (error) {
      console.log(error)
    }
  }

  return (
    <>
    {quiz ? (<>
      <h1 className='fs-2 text-start mb-3 mt-5'>Quiz ID No. {quizID}</h1>
    <div className='p-3 cs-x-center border rounded text-start w100 bg-white' style={{maxWidth: '750px'}}>
    <h1 className='fs-5 fw-bold mb-3'>Question: {quiz[quizIndex].question}</h1>

    <div className="form-check border rounded cs-bg-eexlight mb-3 p-3 border-dark" >
      <input 
      className='form-check-input' type="radio" name="optionOne"
      value={quiz[quizIndex].optionOne}
      checked={answers[quizIndex] === quiz[quizIndex].optionOne}
      onChange={() => handleOptionSelect(quiz[quizIndex].optionOne)}
      />
  
      <label className="form-check-label cs-fs-18" htmlFor="optionOne" >
       <span className='fw-bold'>A. </span> {quiz[quizIndex].optionOne}
      </label>
    </div>
    <div className="form-check border rounded cs-bg-eexlight mb-3 p-3 border-dark" >

       <input 
      className='form-check-input' type="radio" name="optionTwo"
      value={quiz[quizIndex].optionTwo}
      checked={answers[quizIndex] === quiz[quizIndex].optionTwo}
      onChange={() => handleOptionSelect(quiz[quizIndex].optionTwo)}
      />
      <label className="form-check-label cs-fs-18" htmlFor="optionTwo" >
      <span className='fw-bold'>A. </span> {quiz[quizIndex].optionTwo}
      </label>

    </div>
    <div className="form-check border rounded cs-bg-eexlight mb-3 p-3 border-dark" >

       <input 
      className='form-check-input' type="radio" name="optionThree"
      value={quiz[quizIndex].optionThree}
      checked={answers[quizIndex] === quiz[quizIndex].optionThree}
      onChange={() => handleOptionSelect(quiz[quizIndex].optionThree)}
      />
      <label className="form-check-label cs-fs-18" htmlFor="optionThree" >
      <span className='fw-bold'>A. </span> {quiz[quizIndex].optionThree}
      </label>
      </div>
    <div className="form-check border rounded cs-bg-eexlight mb-3 p-3 border-dark" >

       <input 
      className='form-check-input' type="radio" name="optionFour"
      value={quiz[quizIndex].optionFour}
      checked={answers[quizIndex] === quiz[quizIndex].optionFour}
      onChange={() => handleOptionSelect(quiz[quizIndex].optionFour)}
      />
      <label className="form-check-label cs-fs-18" htmlFor="optionFour" >
      <span className='fw-bold'>A. </span> {quiz[quizIndex].optionFour}
      </label>
      </div>
      <div className='flex w100 justify-between'>
 
      {
        quizIndex >= 1 ? (<>
              <button className="btn btn-primary cs-bg-primary border-none w25" onClick={handlePreviousQuestion}>Previous Question</button>
      </>) : null
      }
      {
        quizIndex < quiz.length - 1 ? (<> 
          <button className="btn btn-primary cs-bg-primary border-none w25" onClick={handleNextQuestion}>Next Question</button>
        </>) : null
      }
      {
        complete ? (<>
          <button className="btn btn-primary cs-bg-primary border-none w25" onClick={handleSubmit}>Submit Quiz</button>
        </>) : null
      }
      {console.log(complete)}
      </div>
    </div>
    </>) : null}
    
    </>
  )
}

export default Quiz
import {NavLink} from 'react-router-dom'


const CourseSidePanel = (props) => {
  console.log(props)
  const {courseList, quizList} = props
  return (
  <>
      <div className="col-md-3 w30 list-group list-group-flush bg-white rounded p-3">
          <h1>Lecture List</h1>
          {courseList?.map((element) => {
            return(
              <>
              <button>Lecture #{element.number}</button>
              </>
            )
          })}
          <h1>Quiz List</h1>
          {quizList?.map((element) => {
            return(
              <>
              <button>Lecture #{element.number}</button>
              </>
            )
          })}

      </div>
  </>
  )
}

export default CourseSidePanel
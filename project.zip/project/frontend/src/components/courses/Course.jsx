import {useEffect, useState} from 'react'
import axios from 'axios'
import {useParams, NavLink} from 'react-router-dom'
import Spinner from '../reuse/Spinner'
import Quiz from './Quiz'
import Certificate from './Certificate'

const Course = () => {

  const params = useParams() 
  const [course, setCourse] = useState()
  const [renderLecture, setRenderLecture] = useState(false)
  const [renderQuiz, setRenderQuiz] = useState(false)
  const [renderCertificate, setRenderCertificate] = useState(false)
  const [lect, setLect] = useState()
  const [quiz, setQuiz] = useState()
  const [quizID, setQuizID] = useState('')
  const [dynamicHidden, setDynamicHidden] = useState('dynamicShow')
  const [dynamicWidth, setDynamicWidth] = useState('cs-x-center p-3')
  const [status, setStatus] = useState({})
  const [user, setUser] = useState()

  const submitQuizURL = 'http://localhost:4000/api/course/submit-quiz/'

  const getUser = async () => {
    try {
    const {data} = await axios.get('http://localhost:4000/api/auth/get-user')
    if (data?.success) {
      setUser(data?.user)
    } else {
      console.log("Something Went Wrong in getting User Details", data?.message, data?.error)
    }
  } catch (error) {
    console.log(error)
  }
  }

  const getCourseStatus = async () => {
    try {
    const {data} = await axios.get(`http://localhost:4000/api/course/get-user-enrolled-course/${params.id}`)
    if (data?.success) {
      setStatus(data?.enrolledCourse)
    } else {
      console.log("Something Went Wrong in getting User Details", data?.message, data?.error)
    }
  } catch (error) {
    console.log(error)
  }
  }

  useEffect(() => {
    getUser()
  }, [])

  useEffect(() => {
    if(params?.id) {
      getCourseStatus()
      getProduct()
    }
  }, [params?.id])
  console.log(params.id)
  const getProduct = async() => {
      try {
        const {data} = await axios.get(`http://localhost:4000/api/course/get-course/${params.id}`)
        if(data?.success === false) {
          return console.log("Un Authorized Access")
        }
        setCourse(data?.course)
      } catch (error) {
        
      }
  }

  const showLecture = (lecture) => {
    setLect(lecture)
    setRenderQuiz(false)
    setRenderCertificate(false)
    setRenderLecture(true)
  }

  const showQuiz = (quiz , quizID) => {
    setRenderLecture(false)
    setRenderCertificate(false)
    setRenderQuiz(true)
    setQuiz(quiz)
    setQuizID(quizID)
    setDynamicHidden('dynamicHidden')
  }



  const generateCertificate = async () => {
    try {
      const {data} = await axios.get(`http://localhost:4000/api/course/generate-certificate/${params.id}`)
      if (data?.success) {
        getCourseStatus()
        console.log("Successfully Achieved Certificate")
      }
    } catch (error) {
      
    }
  }


  const viewCertificate = () => {
    setRenderLecture(false)
    setRenderQuiz(false)
    setRenderCertificate(true)
  }
  return (
      course ? (
        <>
      <div className="container-fluid cs-height-def cs-bg-eexlight p-3">
      <div className="row p-3">
        <div className={`col-md-3 list-group list-group-flush ${dynamicHidden} `}>
          <div className='shadow-lg rounded-bottom-4'>
          <h1 className="fs-5 fw-bold cs-linear-tb py-3 border-top rounded-top-4 text-white">Lectures List</h1>
          {course?.lecture.map((lecture) => {
            return (
              <button onClick={() => showLecture(lecture)} key={lecture._id} className="list-group-item list-group-item-action">
                Lecture # {lecture.number}
              </button>
            )
          })}
          <h1 className="fs-5 fw-bold cs-bg-darklight p-2 text-white">Quiz List</h1>

  
          <button onClick={() => showQuiz(course?.quiz1, 'Mid')} className="list-group-item list-group-item-action">
            Half Course Quiz
          </button>
          <button onClick={() => showQuiz(course?.quiz2, 'Final')} className="list-group-item list-group-item-action">
            Final Course Quiz
          </button>
      

          <button onClick={generateCertificate} className="w100 border-none cs-fs-16 fw-bold cs-bg-darklight rounded-bottom-4 p-2 text-white">Generate Certificate</button>

          </div>
 
        </div>
        <div className={`col-md-9 flex flex-col ${dynamicWidth}`}>
        {
            status?.status === true ? (
            <><h1 className='text-success fw-bold'>Congratulations : Course Completed!</h1>
              <button onClick={viewCertificate} className='btn cs-linear-tb text-white rounded fw-bold fs-5 cs-x-center px-4 border-none mb-3' style={{maxWidth: "400px"}}>View Certificate!!!</button>
            </>
            ) : (<>
            <h1 className='text-danger fw-bold'>Incomplete</h1>
            </>) 
        }
          {renderLecture ? ( <>
          <div className="fs-4 w80 border p-3 rounded-pill cs-x-center mb-3 cs-bg-darklight text-white shadow">{lect?.arTitle}</div>
  
          {lect?.video ? (
          <div className="w100" style={{width:'100%', aspectRatio: '16/9'}}>

             <iframe className="w80 rounded-5 shadow" style={{height: '80%', margin: '0 auto'}}
             src={lect?.video } 
             title="YouTube video player" 
             frameBorder="0" 
             allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen />
          </div>
          
          ) : lect?.articleExp ? (
            <>
         

            <div className="w80 border border-dark p-3 text-justify cs-x-center">{lect?.articleExp}</div>
          </>): null}
          </> ) : renderQuiz ? (<>
          <Quiz quiz={quiz} quizID={quizID} url={submitQuizURL} uniqueID={params?.id}/>
          </>) : renderCertificate ? (<>
          <Certificate studentName={user?.name} instructorName={course?.instructor} courseName={course?.name} courseID={course._id}/>
      {JSON.stringify(quiz,null,4)}
          
          </>) 
          
          : (null)}
        </div>
      </div>
    </div>
        </>
      ) : (
        <Spinner />
      )

    
  )
}

export default Course
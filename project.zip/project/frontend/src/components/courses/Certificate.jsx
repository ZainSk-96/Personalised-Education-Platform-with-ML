import React from 'react'

const Certificate = (props) => {

   const {studentName, courseName, courseID, instructorName} = props
  return (
    <div className='border-3 border-dark flex flex-col justify-between pt-5 pb-5 bg-white mt-10 rounded-4' style={{height: '400px'}}>
      <h1 className='cs-certificate-text cs-fs-38 fw-bold border-bottom border-dark w80 cs-x-center'> Certificate Of Completion </h1>
      <p className='cs-certificate-text cs-fs-18'>It is certified that,  
       <span className='ubuntu fw-bold cs-fs-22 ml-3 mr-3' style={{textDecoration: 'underline'}}>  {studentName}  </span>
       has Successfully Completed
      </p> 
      <h2 className='ubuntu cs-fs-32 fw-bolder'>{courseName}</h2>
      <p className='cs-certificate-text'>From {instructorName} </p>

      <div className='justify-content-right'>
        <h1 className='cs-certificate-text' style={{textDecoration: 'underline'}}>Personalized Education Platform LMS</h1>


      </div>

    </div>
  )
}

export default Certificate
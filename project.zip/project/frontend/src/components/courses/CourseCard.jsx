import {useState} from 'react'
import {useNavigate, useParams} from 'react-router-dom'



const CourseCard = (props) => {
  const params = useParams()
  const navigate = useNavigate()
  const [course, setCourse] = useState({})


  const { id, name, description, instructor, category, image } = props 
  
  return (
    <>
        <div className={"card shadow-lg border-none rounded-4"}  style={{width: '20rem', height: '400px', maxHeight: '400px'}}>
       <img src={`http://localhost:4000${image}`} alt='No Course Image Available' className="card-img-top p3 border-dark rounded-top-4 shadow-sm object-fit-cover" style={{maxHeight: '135px'}} />
       <div className="card-body card-flex">
        <h5 className="card-title fs-5">{name}</h5>
        <h6 className="card-subtitle mb-2 text-body-secondary border-bottom rounded w100 text-start">Description:</h6>
        <p className="card-text cs-fs-12 cs-truncate-text">{description}</p>
        <li className="list-group-item cs-fs-12 flex w100 jbetween pt-1 border-top border-dark"><p>Course By:  </p> <p>{instructor}</p></li>
         <button onClick={() => navigate(`/course-details/${id}`)} className="btn btn-primary cs-bg-primary border-none py-2 rounded-3">See Details!</button>
       </div>
      </div>
    </>
  )
}

export default CourseCard
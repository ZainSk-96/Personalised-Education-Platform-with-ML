import React, { useContext } from "react";
import { useAuth } from "./context/AuthContext";
import Sidebar from "./Sidebar";

const Profile = () => {
  const [auth, setAuth] = useAuth();

  return (
    <div className="dashboard-container">
      <Sidebar />
      <div className="profile-container">
        <h2>User Profile</h2>
        {auth && (
          <div>
            <img
              src={auth.profileImage}
              alt="Profile"
              className="profile-image"
            />
            <p>
              <strong>Name:</strong> {auth.name}
            </p>
            <p>
              <strong>Email:</strong> {auth.email}
            </p>
            <p>
              <strong>Age:</strong> {auth.age}
            </p>
            <p>
              <strong>Number:</strong> {auth.number}
            </p>
          </div>
        )}
        {!auth && <p>No user data available.</p>}
      </div>
    </div>
  );
};

export default Profile;

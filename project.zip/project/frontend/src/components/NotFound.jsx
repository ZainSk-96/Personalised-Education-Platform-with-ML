import React from 'react'
import {Link} from 'react-router-dom'

const NotFound = () => {
  return (
    <div className="container-fluid">
      
      <h1 className="cs-font-404 cs-margin-auto">NotFound</h1>
      <Link to="/">
      <h1 className="cs-fs-1 cs-margin-auto">Click Here to Redirect to Home Page!</h1>
      </Link>

    </div>
  )
}

export default NotFound
const Spinner = () => {
    return (
        <>
        <div> Un Authorized Access </div>
        </>
    )
}
export default Spinner
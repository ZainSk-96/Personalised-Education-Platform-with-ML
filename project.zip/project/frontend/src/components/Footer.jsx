import React from "react";

function Footer() {
  return (
    <footer className="bg-gray-700 text-white p-4 text-center cs-bg-dark">
      <div className="container mx-auto">LMS © {new Date().getFullYear()}</div>
    </footer>
  );
}

export default Footer;

//import React, { useContext } from "react";
import { Link } from "react-router-dom";
import {useState, useEffect, useRef} from 'react'
import { useAuth } from "./context/AuthContext.jsx";
import homeImage from "../assets/comp.jpg"
import CourseCard from "./courses/CourseCard.jsx"
import axios from 'axios'
import Typewriter from 'typewriter-effect'


function Home() {
  const [auth, setAuth] = useAuth()
  const [courses, setCourses] = useState([])
  const ref = useRef(null)

  const scrollToContact = ( ) => {
    ref.current?.scrollIntoView({behaviour: 'smooth'})
  }

  const requiredData = {
    reqData: "name instructor description category image"
  }
  const getAllCourses = async () => {
    try {
      const response = await axios.get("http://localhost:4000/api/course/get-courses-for-home")
      const {data} = response
      if (!response) {
       console.log(data.message, data.error)
      }
      setCourses(data?.courses)
    } catch (error) {
      console.log(error)
    }
  }

  useEffect(() => {
    getAllCourses()
  
  }, []) 

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <div className="home-bg-img cs-rounded-bottom home-grid w-100 shadow-lg mb-2">
        <div className="rounded-5 p-3 flex flex-col ml-20" style={{height: '70vh'}}>
          <h1 className="fs-1 fw-bold pt-10">Welcome To</h1>
          <h2 className='fs-1 fw-bold mt-3'>Personalized Education Platform!</h2>
          <h2 className="fs-2 mt-1">Feel free explore our Website to Learn</h2>
 
          
          <h2 className="fs-3 fw-bold cs-font-primary border-bottom border-info w80 cs-x-center mt-3">

          <Typewriter
          options={{
            strings: ['Learn With Us', 'From Your Home!', 'OR', 'From Anywhere', 'Anytime'],
            autoStart: true,
            loop: true,
          }}
        />
          </h2>

          <div className="flex cs-x-center mt-4">
            <Link to="/signup" className="btn fw-bold text-white px-5 py-3 rounded-pill cs-linear-tb border-none mr-3 shadow-lg">Join Us!</Link>
            <Link onClick={scrollToContact} className="btn fw-bold text-white px-5 py-3 rounded-pill cs-lineard-tb border-none shadow-lg">Contact Us</Link>
          </div>


        </div>

        <div className="col-md-6">
       
              
        </div>

      </div>

      {/* Courses Section */}
      <h1 className="fs-1 mt-5 cs-font-primary fw-bolder" id="courses"> Our Courses </h1>

    <div className="p-5 cs-course-grid w100 cs-flexwrap cs-x-center gap-10">
      
        {
        courses.map((c) => {
          return (
          <div className="mb-5 ml-10">
            <CourseCard id={c?._id} description={c?.description} instructor={c?.instructor}
            category={c?.category}
            name={c?.name}
            image={c?.image?.data}
            />
          </div>
          )
        })
      }

    </div>

    {/** Contact Us Page */}
    <div ref={ref} className="cs-bg-dark cs-rounded-top text-white"> 
      <h1 className="fs-1 mt-5 mb-5" id="contact-section" >:Contact Us:</h1>
      <h1 className="fs-4 mt-5 mb-5">Name: Muhammad Zain Shakeel, Muhammad Yasir Ghaffar </h1>
      <h1 className="fs-4 mt-5 mb-5">Roll Number: MC220201007, MC220203542</h1>
      <h1 className="fs-4 mt-5 mb-5 border-bottom pb-2 rounded-bottom-2">Email: mc220201007mzs@vu.edu.pk, mc220203542myg@vu.edu.pk</h1>
    
    </div>
  </div>

      
  );
 
}

export default Home;

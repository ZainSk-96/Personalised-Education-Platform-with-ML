import React, { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { useAuth } from "./context/AuthContext.jsx";
import Sidebar from "./Sidebar";
import {useNavigate} from "react-router-dom"

const Login = () => {
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [auth, setAuth] = useAuth() // use array assigning instead of object destructruing
  const navigate = useNavigate()
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:4000/api/auth/login",
        {email: formData.email, password: formData.password}
      );
      // 
      if (response && response.data.success) {
        setAuth({
          ...auth,
          user: response.data.user,
          token: response.data.token
        });
        localStorage.setItem('auth', JSON.stringify(response.data))
        
        navigate(auth?.user?.role === 1 ? `/dashboard/user/profile` : `/dashboard/admin`) 
        console.log(response)

      } else {
        console.log("Error",response)
      }
      
      
    } catch (error) {
      console.error(error);
      // Handle error
    }
  };

  return (
    <>

      <div className="cs-height-def d-flex cs-bg-eexlight">
        <form className="login-form login-popup" onSubmit={handleSubmit}>
          <h2 className="fw-bold">Login</h2>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Email"
          />
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="Password"
          />
          <div className="form-links">
            <Link to="/Signup">Sign Up</Link>
            <Link to="/forgotpassword">Forgot Password?</Link>{" "}
          </div>
          <button className="cs-linear-tb fw-bold" type="submit">Log In</button>
        </form>
      </div>
    </>
  );
};

export default Login;

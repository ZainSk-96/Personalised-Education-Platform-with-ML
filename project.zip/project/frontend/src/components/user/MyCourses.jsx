import {useState, useEffect} from 'react'
import {useNavigate, useParams} from 'react-router-dom'
import axios from 'axios'
import UserMenu from './UserMenu.jsx'


const MyCourses = () => {
  const params = useParams()
  const navigate = useNavigate()
  const [courses, setCourses] = useState([])
  const [enrollment, setEnrollment] = useState('UnEnroll!')
  const [user, setUser] = useState()

  const getUser = async () => {
    try {
    const {data} = await axios.get('http://localhost:4000/api/auth/get-user')
    if (data?.success) {
      setUser(data?.user)
      setCourses(data?.user?.enrolledCourses)
    } else {
      console.log("Something Went Wrong in getting User Details", data?.message, data?.error)
    }
  } catch (error) {
    console.log(error)
  }
  }
  const unEnrollCourse = async (_id) => {
    try {
      const {data} = await axios.post(`http://localhost:4000/api/course/unenroll-user/${_id}`)
      if (data?.success) {
        setEnrollment("Enroll!")
      } else {
        console.log("Something Went Wrong in getting User Details", data?.message, data?.error)
      }
    } catch (error) {
      console.log(error)
    }
  }

useEffect(()=> {
  getUser()
},[])

  return (
    <>
    <div className="container-fluid cs-height-def">
      <div className="row p-3">
        <div className="col-md-3 p-3 list-group">
          <UserMenu />
        </div>
        <div className="col-md-9 text-start"> 
          
        <h1 className="fs-4 mt-5 mb-3"> Enrolled Courses </h1>
         
         <div className="d-flex gap-3 align-middle">

          {
            courses?.map((element) => {
              return (
                <div className="card w50 shadow-sm" key={element?._id}>
            <div className="card-header shadow-sm fw-bold cs-fs-20">
                {element?.course?.name}
            </div>
            <div className="card-body flex flex-col justify-between">
            <p className="card-text mb-3 border-dark border rounded p-3 cs-bg-eexlight"> Course By: {element?.course?.instructor}</p>
                
              <p className="card-text mb-3 cs-truncate-text-2 px-2">Description: {element?.course?.description}</p>
              <div className="flex justify-between acenter border-top pt-3">
                <button className="p-2 text-white cs-linear-tb rounded-pill" style={{width:'120px'}} onClick={() => navigate(`/dashboard/user/course/${element?.course?._id}`)}> Go To Course! </button>
                <button className="p-2 text-white cs-linear-tb rounded-pill" style={{width:'120px'}} onClick={() => unEnrollCourse(element?.course?._id)}> {enrollment} </button>
              </div>
            </div>
          </div>
              )
            })
          
}
</div>


        </div>
      </div>
    </div>
  </>
  )
}


export default MyCourses
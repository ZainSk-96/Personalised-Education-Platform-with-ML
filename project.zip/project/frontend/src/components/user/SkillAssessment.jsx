import {useState, useEffect} from 'react'
import {useParams, useNavigate} from 'react-router-dom'
import axios from 'axios'
import UserMenu from './UserMenu'
import Quiz from '../courses/Quiz'

const SkillAssessment = () => {


  const [user, setUser] = useState()
  const [skills, setSkills] = useState([])
  const [selectedSkill, setSelectedSkill] = useState({})
  const [quizData, setQuizData] = useState({})
  const [mySkills, setMySkills] = useState([])
  const [skillResult, setSkillResult] = useState()
  const [skillObject, setSkillObject]= useState({})
  const [showQuiz, setShowQuiz] = useState(false)
  const [hideElement, setHideElement] = useState(false)
  
  const submitUrl = 'http://localhost:4000/api/ml/submit-skill-quiz/'

  useEffect(()=> {
    getSkillsFromServer()
    getUser()
    getMySkills()
  },[])

  const getUser = async () => {
    try {
    const {data} = await axios.get('http://localhost:4000/api/auth/get-user')
    if (data?.success) {
      setUser(data?.user)
    } else {
      console.log("Something Went Wrong in getting User Details", data?.message, data?.error)
    }
  } catch (error) {
    console.log(error)
  }
  }

const getSkillsFromServer = async () => {
    try {
      const {data} = await axios.get('http://localhost:4000/api/ml/get-skills-names')
      if (data?.success) {
        setSkills(data?.skills)
      } else {
        console.log("Something Went Wrong in getting User Details", data?.message, data?.error)
      }
    } catch (error) {
      console.log(error)
    }
}
// This is a function for handling quiz and its result 





const skillSelectHandler = (skillID, skillName) => {
  if (!skillID || !skillName) {
    console.log('No Skill Selected Yet')
  } else {
    setSelectedSkill({
      skillID,
      skillName
    })
  }
}

// Retrieve SKills Stored in User Array in userModel Database.
const getMySkills = async() => {
  try {
    const {data} = await axios.get(`http://localhost:4000/api/ml/get-my-skills`) 

    if (data?.success) {
      setMySkills(data?.userSkills?.skills)
    } else {
      console.log(data?.error, data?.message)
    }
  } catch (error) {
    console.log(error)
  }
}

const addSkill = async (skillID) => {
  try {
    const {data} = await axios.post(`http://localhost:4000/api/ml/set-skill/${skillID}`, 
    {skillID}
    )
  
    if (data?.success) {
      console.log('Skill Added Successfully')
      getMySkills()
    } else {
      console.log('Something Went Wrong in assessment handler', data?.error, data?.message)
    }
  } catch (error) {
    console.log(error)
  }
}

const assessmentHandler = (skillInfo) => {
  if(!skillInfo){
    console.log("No Skill Object Selected or Found")
  } else {
    setSkillResult({
      score: skillInfo?.score,
      level: skillInfo?.level
    })
    setQuizData(
      {
        skillID: skillInfo?.skill?._id,
        quiz: skillInfo?.skill?.quiz
      }
    )
  }
} 

const attemptQuiz = () => {
  setShowQuiz(true)
  setHideElement(true)
}

useEffect(()=> {
  if (user) {
    console.log('User:', user);
  }
  if (skills.length > 0) {
    console.log('Skills:', skills);
  }
  if (quizData) {
    console.log('Skills for Assessment:', quizData);
  }  if (mySkills) {
    console.log('My SKILLS:', mySkills);
  }

},[user, skills, quizData, mySkills])

// -------------- Get List of SKills From the Server --------------------




  return ( <>

    <div className="container-fluid cs-height-def">
      <div className="row p-3">
       <div className="col-md-3 p-3">

          <UserMenu />
       </div>


       <div className="col-md-9 p-3">
       {hideElement === false ? (<>
       
        <div className='bg-white rounded'>
          
          </div>
        <h1 className="fs-2 mb-2">Select a Skill from following list to Continue:</h1>
        <p className="text-bg-danger rounded fw-bold pt-2 pb-2 w80 cs-x-center mb-4">Please ADD Skill to your List Before getting Result and Attempting Quiz</p>
          
          <div className="flex  p-3 border border-dark rounded-4 mb-5" style={{flexWrap: 'wrap'}}>
 
           {
           skills?.map(
           (element) => {
             return (<>
             <div key={element?._id} className='mr-1'>
             <span onClick={() => skillSelectHandler(element?._id, element?.name)} className="badge py-2 px-4 btn text-dark btn-info rounded-pill fw-bold cs-fs-14">
               {element?.name} 
             </span>
             </div>
             </>)
 
           })
           }
         </div>
         <h1 className="fs-2 mt-2 mb-1">Skill To Add: <span className="fw-bold text-bg-success px-3 rounded">{selectedSkill?.skillName}</span></h1>
         <div>
         <button className="btn btn-primary cs-linear-tb fs-4 fw-bold border-none mb-2" onClick={() => addSkill(selectedSkill?.skillID)}>Add Skill</button>
         </div>
         <div className="text-start">
         <h1 className="fs-4 fw-bold">My Skills Set</h1>
         <div className="flex  p-3 border border-dark rounded-4 mb-5" style={{flexWrap: 'wrap'}}>
 
           {
           mySkills?.map(
           (element) => {
             return (<>
             <div key={element?._id} className='mr-1'>
             <span onClick={() => assessmentHandler(element)} className="badge py-2 px-4 btn text-dark btn-info rounded-pill fw-bold cs-fs-14">
               {element?.skill?.name} 
             </span>
             </div>
             </>)
 
           })
           }
         </div>
         <button onClick={attemptQuiz} className="btn btn-primary cs-linear-tb fs-4 fw-bold border-none mb-2">Attempt Quiz</button>
           <h1 className="fs-3">My Skill Results: </h1>
           <p className="fs-3"><span className="fw-bold">Skill Level: </span><span className="rounded px-2 py-1 text-bg-success">{skillResult?.level}</span></p>
           <p className="fs-3"><span className="fw-bold">Score: </span><span className="rounded px-2 py-1 text-bg-success">{skillResult?.score}</span> out of 10</p>
 
           
         </div>
       
        </>)
          : null
        }
        
        {showQuiz === true ? (<>
          <Quiz quiz={quizData?.quiz} quizID={quizData?.skillID} url={submitUrl} uniqueID={quizData?.skillID}/>
        
        </>) : null}

       </div>
      </div>
      </div>

  </>
  )
} 



export default SkillAssessment
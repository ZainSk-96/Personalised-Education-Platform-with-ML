import {useState, useEffect} from 'react'
import UserMenu from './UserMenu.jsx'
import SearchApi from '../admin/SearchApi'
import axios from 'axios'

const MyInterests = () => {
  const [interest, setInterest] = useState()
  const [interests, setInterests] = useState([])
  const categoriesURL = "http://localhost:4000/api/category/categories";

  const handleResponse = (category) => {
    setInterest(category)
  }

  const pushInterest = async () => {

    try {
      if (interest) {
        const {data} = await axios.post('http://localhost:4000/api/ml/set-interest', {interestID: interest?._id})
        
        console.log(data?.success, data?.message)
      }
    } catch (error) {
      console.log(error.message)
    }
  }


  const getIntersts = async () => {
    try {
      const {data} = await axios.get('http://localhost:4000/api/ml/get-interests')
      setInterests(data?.interests)
    } catch (error) {
      console.log(error.message)
    }
  }

  useEffect(()=> {
    getIntersts()
  })

  const deleteInterestHandler = async (interestID) => {
    try {
      const {data} = await axios.post('http://localhost:4000/api/ml/delete-interest' , {interestID})
      
      if (data?.success === false ) {
        return console.log(response.data.message)
      }
      getIntersts()
      console.log(data?.message)
    } catch (error) {
      console.log(error.message)
    }
  }

  return (
    <>
    <div className="container-fluid cs-height-def">
      <div className="row p-3">
        <div className="col-md-3 p-3 list-group">
          <UserMenu />
        </div>
        <div className="col-md-9 p-3 w60 cs-x-center">
        <div className='bg-white p-4 border rounded-4 shadow mb-3'>
        <SearchApi
                  url={categoriesURL}
                  dataObject="categories"
                  placeholder="Search Interest"
                  onRecieveRes={handleResponse}
        />
         <h1 className="fs-2 mt-2">Selected Interest: {interest? interest.name : 'No Interest Selected'} </h1>
        
        <button onClick={pushInterest} className="btn mt-3 mb-3 cs-linear-tb text-white">Add Interest </button>

        </div>

        <h2 className="fs-2 mb-3 ">Manage Interests</h2>
       
        <div className="bg-white p-4 border rounded-4 shadow mb-3" style={{maxWidth: '1000px'}}> 

            
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Interest Name</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                { interests?.map((element) => {
                  return (
                    <>
                  <tr key={element._id} className="align-middle">
                  <td>{element.name}</td>
                  <td>
                    <button className="btn btn-secondary cs-bg-dark cs-border-none ml-1 rounded-pill"
                      onClick = {() => deleteInterestHandler(element._id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
                    </>
                  )
                })
                 }
                             
              </tbody>
            </table>
            </div>


        </div>

        
      </div>
    </div>
  </>
  )
}

export default MyInterests
import {useState, useEffect} from 'react'
import {useNavigate} from 'react-router-dom'
import UserMenu from './UserMenu.jsx'
import axios from 'axios'


const UserProfile = () => {
  const navigate = useNavigate()
  const [recommendations, setRecommendations] = useState([])
  const [mySkills, setMySkills] = useState([])
  const [learningPathway, setLearningPathway] = useState([])
  const [user, setUser] = useState()
  const [mySkillLevel, setMySkillLevel] = useState('')
  const [mySkillScore, setMySkillScore] = useState(0)
  const [selectedSkillName, setSelectedSKillName] = useState('No Skill Selected')

  const getRecommendations = async () => {
    try {
    const {data} = await axios.get('http://localhost:4000/api/ml/recommendations')
    if (data?.success) {
      setRecommendations(data?.courses)
    } else {
      console.log("Something Went Wrong ith the response", data?.message, data?.error)
    }
  } catch (error) {
    console.log(error)
  }
  }
  const getUser = async () => {
    try {
    const {data} = await axios.get('http://localhost:4000/api/auth/get-user')
    if (data?.success) {
      setUser(data?.user)
    } else {
      console.log("Something Went Wrong in getting User Details", data?.message, data?.error)
    }
  } catch (error) {
    console.log(error)
  }
  }
  const getUserSkills = async () => {
    try {
      const {data} = await axios.get('http://localhost:4000/api/ml/get-learning-pathway')
      if (data?.success) {
        setMySkills(data?.userSkills?.skills)
      } else {
        console.log("Something Went Wrong in getting User Details", data?.message, data?.error)
      }
    } catch (error) {
      console.log(error)
    }
  }

const generateLearningPathway = (skillInfo) => {
  setMySkillLevel(skillInfo?.level)
  setMySkillScore(skillInfo?.score)

  if (mySkillScore < 4 && mySkillLevel === 'beginner') {
    setLearningPathway(skillInfo?.skill?.beginner)
  } else if 
    (mySkillScore > 4 && mySkilLevel < 8 && mySkillLevel === 'intermediate') {
    setLearningPathway(skillInfo?.skill?.intermediate)

  } else {
    setLearningPathway(skillInfo?.skill?.advanced)
  }

}

useEffect(()=> {
  getRecommendations()
  getUser()
  getUserSkills()
},[])

useEffect(() => {

  console.log(mySkills)

}, [mySkills])


console.log(recommendations)
  return (
    <>
    <div className="container-fluid cs-height-def">
      <div className="row p-3">
      <div className="col-md-3 p-3">

          <UserMenu />
        </div>
        <div className="col-md-9 text-start"> 
          <div className="border border-dark p-3 rounded">
            <h1 className="fs-3 border-bottom mb-3"> Welcome Back! </h1>
            <h4 className="fs-5 mb-3">Name: {user?.name}</h4>
            <h4 className="fs-5 mb-3">Email: {user?.email}</h4>



          </div>

          <h1 className="fs-4 mt-5 mb-3"> Recommended Courses </h1>
         
         <div className="flex gap-3 align-middle">

          {
            recommendations?.map((element) => {
              return (
                <div className="card w50 shadow-sm" key={element._id}>
            <div className="card-header">
              Recommended Course
            </div>
            <div className="card-body flex flex-col justify-between">
              <h5 className="card-title fs-5">{element?.name}</h5>
              <p className="card-text mb-3 cs-truncate-text-2">{element?.description}</p>
              <button className="p-2 cs-linear-tb text-white rounded-pill" style={{width: '150px'}} onClick={() => navigate(`/course-details/${element._id}`)}> See Details </button>
            </div>
          </div>
              )
            })
          
            }
          </div>
          <h1 className="fs-4 fw-bold mt-4">Recommended Learning Pathways: </h1>
          <p className="cs-fs-18 mb-3"> Please Select a Skill from your Skills Set</p>
          <p className="fw-bold">My SkillSet:</p>
          <div className="flex  p-3 border border-dark rounded-4 mb-2 cs-x-center" style={{maxWidth: '900px', flexWrap: 'wrap'}}>


            {
            mySkills?.map(
            (element) => {
              return (<>
              <div key={element?._id} className='mr-1'>
              <span onClick={() => generateLearningPathway(element)} className="badge py-2 px-4 btn text-dark btn-info rounded-pill fw-bold cs-fs-14">
                {element?.skill?.name} 
              </span>
              </div>
              </>)

            })
            }
            </div>

           
              <h1 className="fs-5 fw-bold">Selected Skill: {selectedSkillName}</h1>
              <h3 className="fs-6 fw-bold">Current Skill Level: {mySkillLevel}</h3>
              <h3 className="fs-6 fw-bold mb-2">Current Skill Score: {mySkillScore}</h3>
              <h1 className="fs-4 fw-bold">Recommended Pathway For <span className='text-bg-success rounded px-2 py-1'>{mySkillLevel}</span> Level</h1>
             
              <div className="bg-white rounded 4 p-3 cs-x-center shadow mt-3" style={{maxWidth: '750px'}}>
              <ol className="list-group list-group-numbered list-group-flush" >

              {learningPathway.map((title) => {
                return (
                  <>
                    <li key={title} className='list-group-item '>{title}</li>
                  
                  </>
                )
              })}
                  </ol>

            </div>


        </div>
      </div>
    </div>
  </>
  )
}

export default UserProfile
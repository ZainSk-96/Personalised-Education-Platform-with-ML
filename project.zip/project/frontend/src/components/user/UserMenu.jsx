import React from 'react'
import {NavLink} from 'react-router-dom'
const UserMenu = () => {
  return (
  <>
  <div className='list-group shadow'>
    <NavLink to="/dashboard/user/profile" className="list-group-item list-group-item-action bg-transparent" aria-current="true">
      Profile
    </NavLink>
    <NavLink to="/dashboard/user/my-courses" className="list-group-item list-group-item-action">
      My Courses
    </NavLink>
    <NavLink to="/dashboard/user/my-interests" className="list-group-item list-group-item-action">
      My Goals and Interests
    </NavLink>
    <NavLink to="/dashboard/user/skill-assessment" className="list-group-item list-group-item-action">
      Skills Assessment
    </NavLink>
  </div>
  </>
  )
}

export default UserMenu
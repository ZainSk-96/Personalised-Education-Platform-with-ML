import UserMenu from './UserMenu.jsx'


const MyCertificates = () => {
  return (
    <>
    <div className="container-fluid cs-height-def">
      <div className="row p-3">
      <div className="col-md-3 p-3 list-group">

          <UserMenu />
        </div>
        <div className="col-md-9">
          My Certificates are Shown Here
        </div>
      </div>
    </div>
  </>
  )
}

export default MyCertificates